"""Economic invariants, input rejection and parity of Python/browser engines."""
import json
import math
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
from valuation import evaluate, load_csv

DATA = json.loads((ROOT / "dist/demo.json").read_text())
ROWS, OPT = DATA["loans"], DATA["meta"]["defaults"]

class ValuationTests(unittest.TestCase):
    def test_balance_reconciles_without_double_count(self):
        r = evaluate(ROWS, OPT)
        self.assertAlmostEqual(r["face"], r["eligible"] + r["excluded"] + r["review"], places=6)
        self.assertAlmostEqual(r["gross_total"], sum(s["gross"] for s in r["segments"].values()), places=6)
        self.assertAlmostEqual(sum(r["net"]) + sum(r["costs"]), r["gross_total"], places=6)

    def test_zero_discount_equals_undiscounted_net_cash(self):
        r = evaluate(ROWS, {**OPT, "annual_return": 0})
        self.assertAlmostEqual(r["max_price"], sum(r["net"]) - OPT["startup"], places=6)

    def test_irr_equals_hurdle_at_maximum_price(self):
        a = evaluate(ROWS, OPT)
        b = evaluate(ROWS, {**OPT, "price": a["max_price"]})
        self.assertAlmostEqual(b["npv"], 0, places=7)
        self.assertAlmostEqual(b["irr"], OPT["annual_return"], places=9)

    def test_delay_preserves_recoveries_and_discounts_timing(self):
        a = evaluate(ROWS, {**OPT, "cost_mode": "simple"})
        b = evaluate(ROWS, {**OPT, "cost_mode": "simple", "delay": 6})
        self.assertEqual(len(b["net"]), 42)
        self.assertEqual(b["net"][:6], [0.] * 6)
        self.assertAlmostEqual(a["gross_total"], b["gross_total"], places=6)
        expected = (a["max_price"] + OPT["startup"]) / (1 + OPT["annual_return"]) ** .5 - OPT["startup"]
        self.assertAlmostEqual(b["max_price"], expected, places=6)

    def test_price_does_not_change_asset_cashflows(self):
        a, b = evaluate(ROWS, OPT), evaluate(ROWS, {**OPT, "price": OPT["price"] + 100000})
        self.assertEqual(a["net"], b["net"])
        self.assertAlmostEqual(a["npv"] - b["npv"], 100000, places=6)
        self.assertLess(b["irr"], a["irr"])

    def test_worse_recovery_cost_and_delay_reduce_value(self):
        a = evaluate(ROWS, OPT)
        for delta in ({"multiplier": .8}, {"cost_rate": .3}, {"delay": 3}):
            self.assertLess(evaluate(ROWS, {**OPT, **delta})["max_price"], a["max_price"])

    def test_all_review_and_zero_collections(self):
        r = evaluate([{**x, "quality": "review"} for x in ROWS], OPT)
        self.assertEqual(r["eligible"], 0)
        self.assertLess(r["max_price"], -OPT["startup"])
        self.assertIsNone(r["irr"])
        self.assertIsNone(r["payback"])
        self.assertEqual(evaluate(ROWS, {**OPT, "multiplier": 0})["gross_total"], 0)

    def test_bad_inputs_rejected(self):
        for rows in ([], [ROWS[0], ROWS[0]], [{**ROWS[0], "principal": -1}],
                     [{**ROWS[0], "excluded_amount": 1e9}], [{**ROWS[0], "principal": float("nan")}],
                     [{**ROWS[0], "segment": "unknown"}]):
            with self.assertRaises(ValueError): evaluate(rows, OPT)
        for delta in ({"price": 0}, {"cost_rate": 1}, {"delay": 1.5}, {"annual_return": float("inf")}):
            with self.assertRaises(ValueError): evaluate(ROWS, {**OPT, **delta})

    def test_csv_round_trip(self):
        csv_rows = load_csv(ROOT / "dist/demo-register.csv")
        self.assertEqual(csv_rows, ROWS)

    def test_python_javascript_parity(self):
        configurations = [OPT, {**OPT, "delay": 12, "multiplier": .8, "cost_rate": .4},
                          {**OPT, "annual_return": 0, "multiplier": 0},
                          {**OPT, "price": 7e6, "annual_return": 1.5},
                          {**OPT, "cost_mode": "simple"},
                          {**OPT, "extra_costs": [{"label": "Late expense", "month": 60, "amount": 5000000}]}]
        script = "const e=require('./dist/engine.js');const d=require('./dist/demo.json');const c=JSON.parse(process.argv[1]);console.log(JSON.stringify(c.map(o=>e.evaluate(d.loans,o))));"
        result = json.loads(subprocess.check_output(["node", "-e", script, json.dumps(configurations)], cwd=ROOT))
        def compare(a,b):
            if isinstance(a, dict):
                self.assertEqual(set(a),set(b))
                for k in a: compare(a[k],b[k])
            elif isinstance(a,list):
                self.assertEqual(len(a),len(b))
                for x,y in zip(a,b):compare(x,y)
            elif isinstance(a,(int,float)):
                self.assertTrue(math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-6),(a,b))
            else:self.assertEqual(a,b)
        for o,b in zip(configurations,result):compare(evaluate(ROWS,o),b)

    def test_cost_allocation_and_contributions_reconcile(self):
        r = evaluate(ROWS, OPT)
        self.assertAlmostEqual(sum(r["allocation"].values()), r["cost_total"], places=5)
        self.assertAlmostEqual(sum(r["category_totals"].values()) + OPT["startup"], r["cost_total"], places=5)
        self.assertAlmostEqual(sum(x["contribution"] for x in r["records"]) - r["shared_pv"], r["max_price"], places=5)

    def test_nonpayers_still_cost_money(self):
        r = evaluate(ROWS, {**OPT, "payer_multiplier": 0})
        self.assertEqual(r["gross_total"], 0)
        self.assertEqual(r["payers"], 0)
        self.assertGreater(r["allocation"]["nonpayers"], 0)
        self.assertGreater(r["category_totals"]["legal"], 0)
        self.assertIsNone(r["break_even_average"])

    def test_cash_gap_and_sustained_payback(self):
        r = evaluate(ROWS, {**OPT, "delay": 6})
        self.assertGreater(r["operating_cash_gap"], 0)
        self.assertAlmostEqual(r["funding_peak"], -min(r["cash_balance"]), places=6)
        late = evaluate(ROWS, {**OPT, "extra_costs": [{"label": "Late cost", "month": 60, "amount": 9000000}]})
        self.assertEqual(len(late["net"]), 60)
        self.assertIsNone(late["payback"])
        self.assertIsNone(late["irr"])
        self.assertEqual(late["irr_status"], "nonconventional")

    def test_break_even_average_includes_commission(self):
        r = evaluate(ROWS, OPT)
        collections = r["payers"] * r["break_even_average"]
        noncommission = sum(r["costs"]) - r["category_totals"]["commission"]
        expenses = noncommission + collections * OPT["cost_rate"] * OPT["expense_multiplier"] + OPT["startup"]
        self.assertAlmostEqual(collections - expenses - OPT["price"], 0, places=6)

    def test_future_extra_cost_is_discounted_once(self):
        a = evaluate(ROWS, OPT)
        b = evaluate(ROWS, {**OPT, "extra_costs": [{"label": "Expertise", "month": 4, "amount": 100000}]})
        self.assertAlmostEqual(a["profit"] - b["profit"], 100000, places=6)
        self.assertAlmostEqual(a["max_price"] - b["max_price"], 100000 / (1 + OPT["annual_return"]) ** (4/12), places=6)

    def test_simple_mode_replaces_instead_of_adding_detailed_costs(self):
        r = evaluate(ROWS, {**OPT, "cost_mode": "simple", "cost_rate": .18})
        self.assertAlmostEqual(r["cost_total"], r["gross_total"] * .18 + OPT["startup"], places=6)
        self.assertEqual(r["category_totals"]["team"], 0)

if __name__ == "__main__": unittest.main()
