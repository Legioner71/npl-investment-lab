"""Check Python invocation of the shared recovery simulator and UTF-8 paths."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

class MonteCarloCLITests(unittest.TestCase):
    def test_cli_preserves_inputs_and_returns_reproducible_engine_result(self):
        with tempfile.TemporaryDirectory(prefix='npl-mc-') as folder:
            directory = Path(folder)
            config = directory / 'параметри.json'
            output = directory / 'результат.json'
            config.write_text(json.dumps({'draws': 100, 'seed': 991}), encoding='utf-8')
            subprocess.run([sys.executable, str(ROOT / 'python/monte_carlo.py'),
                            str(ROOT / 'dist/demo.json'), '--params', str(config),
                            '--output', str(output)], capture_output=True, text=True,
                           encoding='utf-8', check=True)
            result = json.loads(output.read_text(encoding='utf-8'))
            direct = subprocess.run(['node', str(ROOT / 'dist/monte-carlo.js'),
                                     str(ROOT / 'dist/demo.json'), str(config)],
                                    capture_output=True, text=True, encoding='utf-8', check=True)
            self.assertEqual(result, json.loads(direct.stdout))
            self.assertEqual(result['engine'], 'npl-mc-v1')
            self.assertEqual(len(result['samples']), 100)
            self.assertNotIn('rows', result)
            self.assertNotIn('loans', result)
            self.assertGreater(result['metrics']['cost_total']['min'], 0)

if __name__ == '__main__':
    unittest.main()
