'use strict';
const assert=require('node:assert/strict'),NPL=require('../dist/engine.js'),R=require('../dist/risk-engine.js'),d=require('../dist/demo.json');
const close=(a,b)=>assert.ok(Math.abs(a-b)<=Math.max(1e-6,Math.abs(b)*1e-10),`${a} != ${b}`);
const meta={id:'test',name:'Test',source:'synthetic',created_at:'2026-10-30T00:00:00Z'};
const sample=(delta={},loans=d.loans)=>R.snapshot(loans,{...d.meta.defaults,...delta},meta,NPL.evaluate);
let n=0;function test(name,fn){fn();n++;console.log('✓ '+name);}
test('Paired summaries match the existing financial engine across rates, prices, delays and cost modes',()=>{
  for(const delta of [{},{annual_return:0},{price:8e6},{delay:6,payer_multiplier:.5,multiplier:1.3,expense_multiplier:1.4},{cost_mode:'simple',cost_rate:.2},{extra_costs:[{label:'Late outflow',month:60,amount:5e6}]}]){
    const o={...d.meta.defaults,...delta},s=sample(delta),a=NPL.evaluate(d.loans,o),b=NPL.evaluate(d.loans,R.stressOptions(a.options)),m=R.measure(s,a.options.annual_return);
    for(const [computed,expected] of [[m.base,a],[m.stress,b]]){for(const k of ['npv','funding_peak','profit'])close(computed[k],expected[k]);assert.equal(computed.irr_status,expected.irr_status);for(const k of ['irr','payback'])expected[k]===null?assert.equal(computed[k],null):close(computed[k],expected[k]);}
    close(m.risk_pct,(a.npv-b.npv)/(o.price+o.startup)*100);
  }
});
test('Stress is relative to each base, retaining purchase, startup and payer amount assumptions',()=>{
  const o={...d.meta.defaults,payer_multiplier:.7,expense_multiplier:1.4,multiplier:1.3,delay:6};
  const stress=R.stressOptions(o);close(stress.payer_multiplier,.56);close(stress.expense_multiplier,1.75);assert.equal(stress.delay,9);assert.equal(stress.multiplier,1.3);assert.equal(stress.price,o.price);assert.equal(stress.startup,o.startup);
});
test('Initial outlay denominator includes startup exactly once; deterioration is not clipped',()=>{
  const s=sample(),m=R.measure(s,.6);close(m.initial,s.price+s.startup);close(m.risk_pct,m.decline/m.initial*100);
  const better=structuredClone(s);better.flows.stress=structuredClone(s.flows.base);better.flows.stress.gross=better.flows.stress.gross.map(v=>v*1.2);assert.ok(R.measure(better,.6).risk_pct<0);
});
test('Common discount reprices both flows without altering IRR or frozen snapshots',()=>{
  const s=sample(),frozen=JSON.stringify(s),a=R.measure(s,0),b=R.measure(s,1);close(a.base.irr,b.base.irr);assert.ok(b.base.npv<a.base.npv);assert.notEqual(a.risk_pct,b.risk_pct);assert.equal(JSON.stringify(s),frozen);
});
test('Unknown/legal-review-only collections have no IRR point and retain all collection costs',()=>{
  const s=sample({},d.loans.map(r=>({...r,quality:'review'}))),m=R.measure(s,.6);assert.equal(m.base.gross,0);assert.ok(m.base.future_cost>0);assert.equal(m.plottable,false);assert.equal(m.base.irr,null);assert.equal(m.status,'base_fails');
});
test('Later material outflows do not yield an arbitrary IRR',()=>{
  const m=R.measure(sample({extra_costs:[{label:'Late outflow',month:60,amount:5e6}]}),.6);assert.equal(m.base.irr_status,'nonconventional');assert.equal(m.plottable,false);
});
test('Import ignores supplied derived scores and recomputes all metrics from flows',()=>{
  const s=sample(),fake={...s,risk_pct:0,irr:1000,html:'<script>bad</script>'};
  const p=R.validateCollection({schema:R.SCHEMA,policy:R.POLICY,annual_return:.6,snapshots:[fake]},{imported:true});assert.equal(p.snapshots[0].source,'imported');assert.equal(p.snapshots[0].html,undefined);assert.equal(p.snapshots[0].irr,undefined);close(R.measure(p.snapshots[0],.6).risk_pct,R.measure(s,.6).risk_pct);
});
test('Corrupt, non-finite, incompatible, duplicate and oversized comparison data are rejected atomically',()=>{
  const s=sample(),pack={schema:R.SCHEMA,policy:R.POLICY,annual_return:.6,snapshots:[s]};
  for(const change of [{price:0},{price:Infinity},{startup:-1},{startup:1e308},{source:'unknown'},{policy:'wrong'},{review_count:50001},{flows:{base:{gross:[NaN],costs:[0]},stress:s.flows.stress}}])assert.throws(()=>R.validateSnapshot({...s,...change}));
  assert.throws(()=>R.validateCollection({...pack,snapshots:[s,s]}));assert.throws(()=>R.validateCollection({...pack,snapshots:[{...s,id:'live'}]}));assert.throws(()=>R.validateCollection({...pack,annual_return:NaN}));assert.throws(()=>R.validateCollection({...pack,snapshots:Array.from({length:R.LIMIT+1},(_,i)=>({...s,id:'x'+i}))}));assert.throws(()=>R.stressOptions({...d.meta.defaults,delay:22}));
});
test('CSV uses recomputed metrics and neutralizes spreadsheet-formula names',()=>{
  const s={...sample(),name:'=1+1'},csv=R.csv([s],.6);assert.ok(csv.includes("\"'=1+1\""));assert.ok(csv.includes('npv_decline_pct_initial'));assert.ok(csv.includes(String(R.measure(s,.6).risk_pct)));
});
console.log(n+' risk-map checks passed');
