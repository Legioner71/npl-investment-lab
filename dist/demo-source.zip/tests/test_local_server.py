import queue
import subprocess
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class LocalServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.process=subprocess.Popen([sys.executable,str(ROOT/'run_local.py'),'--no-browser','--port','0'],cwd=cls.temp.name,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        lines=queue.Queue()
        def capture():
            for line in cls.process.stdout:lines.put(line.strip())
        threading.Thread(target=capture,daemon=True).start()
        try:
            lines.get(timeout=5)
            cls.url=lines.get(timeout=5)
            if not cls.url.startswith('http://127.0.0.1:'):raise AssertionError(cls.url)
        except Exception:
            cls.process.terminate();cls.process.wait(timeout=5);cls.temp.cleanup();raise

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate();cls.process.wait(timeout=5)
        cls.process.stdout.close();cls.temp.cleanup()

    def fetch(self,path):
        with urllib.request.urlopen(self.url+path,timeout=5) as r:return r.status,r.headers,r.read()

    def test_serves_app_from_an_unrelated_working_directory(self):
        status,headers,body=self.fetch('')
        self.assertEqual(status,200)
        self.assertIn('Стратегія'.encode(),body)
        self.assertIn('no-store',headers['Cache-Control'])

    def test_required_assets_are_available(self):
        for name in ('app.js','strategy-engine.js','model-comparison.json','model-bundle.json','strategy-input-demo.json'):
            status,_,body=self.fetch(name)
            self.assertEqual(status,200);self.assertGreater(len(body),10)

    def test_source_outside_dist_is_not_served(self):
        for name in ('README.md','python/prepurchase.py','.git/config'):
            with self.assertRaises(urllib.error.HTTPError) as caught:self.fetch(name)
            self.assertEqual(caught.exception.code,404)

if __name__=='__main__':unittest.main()
