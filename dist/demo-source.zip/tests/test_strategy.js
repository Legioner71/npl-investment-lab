'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const S=require('../dist/strategy-engine.js'),P=require('../dist/prepurchase-engine.js');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8')),clone=v=>JSON.parse(JSON.stringify(v));
const pack=read('dist/prepurchase-case.json'),ops=read('dist/strategy-operations.json'),model=read('dist/prepurchase-model.json'),forecast=P.scorePackage(model,pack);
const result=S.buildPlans(pack,ops,forecast),params=S.DEFAULTS;
const close=(a,b,tolerance=1e-6)=>assert.ok(Math.abs(a-b)<=tolerance,`${a} != ${b}`);
let passed=0;function test(name,fn){fn();passed++;console.log('✓ '+name);}

test('90 days, 13 weeks, prorated last week and continuous calendar',()=>{
  for(const p of result.plans){assert.equal(p.weeks.length,13);assert.equal(p.weeks.reduce((s,w)=>s+w.days,0),90);assert.equal(p.weeks.at(-1).days,6);
    assert.equal(p.end_date,S.addDays(p.start_date,89));
    p.weeks.forEach((w,i)=>{assert.equal(w.start_date,S.addDays(p.start_date,i*7));if(i)assert.equal(w.start_date,S.addDays(p.weeks[i-1].end_date,1));});
  }
});
test('Financial layers reconcile, fixed salaries include idle capacity and reserve is not an expense',()=>{
  for(const p of result.plans){
    const sum=k=>p.weeks.reduce((s,w)=>s+w[k],0);
    for(const k of ['gross','base_gross','incremental_gross','fixed_cost','external_cost','commission','cost','net'])close(sum(k),p.totals[k]);
    close(p.totals.cost,p.totals.fixed_cost+p.totals.external_cost+p.totals.commission);
    close(p.totals.gross,p.totals.base_gross+p.totals.incremental_gross);close(p.totals.net,p.totals.gross-p.totals.cost);
    close(p.totals.npv,p.totals.baseline_npv+p.totals.incremental_npv);
    close(p.totals.fixed_cost,(12*250+20*200+8*500+2000+1200)*90/7);
    close(p.budget.reserve,40000);close(p.budget.spend_limit,360000);assert.ok(p.totals.cost<=p.budget.spend_limit);
  }
  close(result.plans[0].totals.fixed_cost,result.plans[2].totals.fixed_cost);
});
test('Weekly staff limits and borrower contact coordination are enforced',()=>{
  for(const p of result.plans)for(const w of p.weeks){
    for(const s of Object.values(w.staff))assert.ok(s.used<=s.capacity+1e-9);
    const contacts=w.tasks.filter(t=>S.ROUTES[t.route].cash),ids=contacts.map(t=>t.borrower_id);assert.equal(new Set(ids).size,ids.length);
    close(w.staff.operator.used,w.tasks.filter(t=>t.role==='operator').reduce((s,t)=>s+t.hours,0));
  }
});
test('Blocked or unverified contacts never receive contact tasks, including other loans of a blocked borrower',()=>{
  const blocked=new Set(ops.accounts.filter(a=>a.contact_status==='blocked').map(a=>pack.snapshots.find(s=>s.loan_id===a.loan_id).borrower_id));
  for(const p of result.plans)for(const t of p.weeks.flatMap(w=>w.tasks).filter(t=>S.ROUTES[t.route].cash)){
    const op=ops.accounts.find(a=>a.loan_id===t.loan_id);assert.equal(op.contact_status,'allowed');assert.equal(op.rules_verified,true);assert.ok(!blocked.has(t.borrower_id));
  }
});
test('Unknown forecasts and pending legal documents stay unestimated; all accounts incur servicing',()=>{
  for(const p of result.plans){
    assert.equal(p.coverage.total,1200);assert.equal(p.coverage.model_scored,1090);assert.ok(p.coverage.legal_hold>0);
    for(const r of p.rows)if(r.forecast_status!=='scored'||r.route==='legal_review')assert.equal(r.base_90d,null);
    close(p.params.servicing_account_week*p.coverage.total*90/7,1200*90/7);
    for(const t of p.weeks.flatMap(w=>w.tasks).filter(t=>!S.ROUTES[t.route].cash))assert.equal(t.incremental_gross,0);
  }
});
test('Insufficient base budget exposes a shortfall and never silently erases costs',()=>{
  const r=S.buildPlans(pack,ops,forecast,{budget:1000});assert.equal(r.recommendation,null);
  for(const p of r.plans){assert.equal(p.budget.feasible,false);assert.equal(p.task_count,0);assert.ok(p.budget.funding_shortfall>0);assert.ok(p.totals.cost>1000);}
});
test('No uplift or a 90 day effect lag produces no discretionary contact tasks',()=>{
  for(const delta of [{support_uplift:0,offer_uplift:0},{support_lag_days:90,offer_lag_days:90}]){
    const r=S.buildPlans(pack,ops,forecast,delta);assert.equal(r.recommendation,null);
    for(const p of r.plans){assert.equal(p.totals.incremental_gross,0);assert.equal(p.weeks.flatMap(w=>w.tasks).filter(t=>S.ROUTES[t.route].cash).length,0);}
  }
});
test('Action cash never precedes activation and totals equal remaining-horizon effect',()=>{
  const row=pack.snapshots.find(s=>s.quality==='ready'&&s.history_complete);
  const c={meta:{synthetic:true},snapshots:[row],payments:[]},o={accounts:[{loan_id:row.loan_id,contact_status:'allowed',rules_verified:true,active_payment_plan:false,legal_review_required:false,updated_at:'2026-10-28'}]};
  const f={horizon_months:12,scores:[forecast.scores.find(s=>s.loan_id===row.loan_id)]};
  const p=S.buildPlans(c,o,f).plans[2],t=p.weeks.flatMap(w=>w.tasks)[0];assert.equal(t.activation_day,21);
  close(p.totals.incremental_gross,p.totals.base_gross*.2*(90-21)/90);
  p.weeks.filter(w=>w.end_day<=21).forEach(w=>assert.equal(w.incremental_gross,0));
});
test('Cash is capped by the claim balance',()=>{
  const f=clone(forecast);f.scores.forEach(s=>{if(s.status==='scored'){const a=pack.snapshots.find(a=>a.loan_id===s.loan_id);s.probability=1;s.conditional=a.principal+a.interest+a.penalty-a.excluded_amount;s.expected=s.conditional;}});
  const r=S.buildPlans(pack,ops,f,{share_90d:1,support_uplift:1,offer_uplift:1});for(const p of r.plans){assert.equal(p.totals.incremental_gross,0);}
});
test('Missing operations means internal checks, never assumed permission',()=>{
  const r=S.buildPlans(pack,{accounts:[]},forecast);for(const p of r.plans)assert.equal(p.weeks.flatMap(w=>w.tasks).filter(t=>S.ROUTES[t.route].cash).length,0);
});
test('Malformed forecasts, duplicate operations, future flags, stale horizon and invalid inputs are rejected',()=>{
  const duplicate=clone(ops);duplicate.accounts.push(duplicate.accounts[0]);assert.throws(()=>S.buildPlans(pack,duplicate,forecast));
  const future=clone(ops);future.accounts[0].updated_at='2027-01-01';assert.throws(()=>S.buildPlans(pack,future,forecast));
  const bad=clone(forecast);const score=bad.scores.find(s=>s.status==='scored');score.expected+=100;assert.throws(()=>S.buildPlans(pack,ops,bad));
  assert.throws(()=>S.buildPlans(pack,ops,forecast,{start_date:'2028-01-01'}));
  assert.throws(()=>S.buildPlans(pack,ops,forecast,{budget:NaN}));assert.throws(()=>S.buildPlans(pack,ops,forecast,{overhead_week:1e308}));
  assert.throws(()=>S.buildPlans(pack,ops,forecast,{share_90d:2}));assert.throws(()=>S.buildPlans(pack,ops,forecast,{start_date:'2026-02-30'}));
});
test('Future payment fields cannot change a plan based on a fixed pre-purchase forecast',()=>{
  const c=clone(pack);c.payments.push({loan_id:c.snapshots[0].loan_id,payment_date:'2027-01-01',available_at:'2027-01-01',amount:1e8});
  assert.deepEqual(S.buildPlans(c,ops,forecast).plans,result.plans);
});
test('Weekly actuals trigger review without mutating the initial plan',()=>{
  const p=result.plans[2],before=JSON.stringify(p),w=p.weeks[0],r=S.reviewWeek(p,1,w.gross*.5,w.cost*1.5);
  assert.equal(r.review_required,true);assert.deepEqual(r.flags,['collections_below_plan','costs_above_plan']);assert.equal(JSON.stringify(p),before);
  assert.throws(()=>S.reviewWeek(p,1,-1,0));assert.throws(()=>S.reviewWeek(p,14,0,0));
});
console.log(`${passed} strategy checks passed`);
