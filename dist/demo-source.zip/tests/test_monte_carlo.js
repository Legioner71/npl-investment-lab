'use strict';
const assert=require('node:assert/strict'),NPL=require('../dist/engine.js'),MC=require('../dist/monte-carlo.js'),d=require('../dist/demo.json');
const close=(a,b,tol=1e-7)=>assert.ok(Math.abs(a-b)<=tol*Math.max(1,Math.abs(b)),`${a} != ${b}`);
let count=0;function test(name,fn){fn();count++;console.log('✓ '+name);}
const p={draws:1000,seed:42,common_rho:0,borrower_share:0,amount_spread:0,cost_spread:0,delay_jitter:0};
const certain=d.loans.filter(r=>r.segment==='bank_early').slice(0,20).map(r=>({...r,quality:'ready'}));
const deterministic=(delta={})=>({...d.meta.defaults,payer_multiplier:3,...delta});
test('Certain payers and zero uncertainty reproduce original DCF, all costs, funding and payback',()=>{
  for(const delta of [{},{cost_mode:'simple'},{delay:8,annual_return:0},{extra_costs:[{label:'Late',month:84,amount:7e5}]}]){
    const o=deterministic(delta),base=NPL.evaluate(certain,o),r=MC.run(certain,o,{...p,draws:2});
    for(const s of r.samples){for(const [a,b] of [[s.npv,base.npv],[s.profit,base.profit],[s.gross,base.gross_total],[s.cost_total,base.cost_total],[s.funding_peak,base.funding_peak]])close(a,b);if(base.payback===null)assert.equal(s.payback,null);else close(s.payback,base.payback);}
    close(r.curves[0].p50,-o.price-o.startup);close(r.curves.at(-1).p50,base.profit);assert.equal(r.horizon,base.gross.length);
  }
});
test('No modeled collections retain nonpayer/review expenses; review is separate from nonpayers',()=>{
  for(const loans of [d.loans.map(r=>({...r,quality:'review'})),d.loans]){
    const o={...d.meta.defaults,payer_multiplier:0},r=MC.run(loans,o,{...p,draws:10});assert.equal(r.modeled_contracts,0);assert.equal(r.metrics.gross.max,0);assert.ok(r.metrics.cost_total.min>0);assert.equal(r.payback_conditional,null);assert.equal(r.probabilities.capital_loss.value,1);assert.equal(r.review_count,loans.filter(r=>r.quality==='review').length);
  }
});
test('Seed exactly reproduces all results without mutating rows or options; different seed differs',()=>{
  const rows=JSON.stringify(d.loans),o=JSON.stringify(d.meta.defaults),params={...p,draws:300,common_rho:.1,cost_spread:.2,delay_jitter:3,amount_spread:.4};const a=MC.run(d.loans,d.meta.defaults,params),b=MC.run(d.loans,d.meta.defaults,params),c=MC.run(d.loans,d.meta.defaults,{...params,seed:43});assert.deepEqual(a,b);assert.notDeepEqual(a.samples,c.samples);assert.equal(JSON.stringify(d.loans),rows);assert.equal(JSON.stringify(d.meta.defaults),o);
});
test('Gaussian factors preserve marginal payment probability and conditional bounded recovery mean',()=>{
  const loan={...certain[0],borrower_id:'one'},o={...d.meta.defaults,price:1000},base=NPL.evaluate([loan],o),r=MC.run([loan],o,{...p,draws:20000,common_rho:.25,borrower_share:.8,amount_spread:1});assert.ok(Math.abs(r.metrics.payers.mean-base.payers)<.015);assert.ok(Math.abs(r.metrics.gross.mean/base.gross_total-1)<.025);const cap=loan.principal+loan.interest+loan.penalty-loan.excluded_amount;assert.ok(r.metrics.gross.min>=0&&r.metrics.gross.max<=cap+1e-7);
});
test('Common and borrower dependence increase count dispersion without collapsing marginal probabilities',()=>{
  const loans=Array.from({length:30},(_,i)=>({...certain[0],loan_id:'l'+i,borrower_id:'b'+i})),same=loans.map(r=>({...r,borrower_id:'same'}));const o={...d.meta.defaults,price:1000},ind=MC.run(loans,o,{...p,draws:4000}),global=MC.run(loans,o,{...p,draws:4000,common_rho:.3}),grouped=MC.run(same,o,{...p,draws:4000,borrower_share:.9});const variance=r=>r.samples.reduce((s,x)=>s+(x.payers-r.metrics.payers.mean)**2,0)/r.params.draws;assert.ok(variance(global)>variance(ind)*4);assert.ok(variance(grouped)>variance(ind)*8);assert.ok(Math.abs(global.metrics.payers.mean-15)<1);assert.ok(Math.abs(grouped.metrics.payers.mean-15)<1);
});
test('Higher bad common shock combines fewer payers with higher costs and later collection dates',()=>{
  const r=MC.run(d.loans,d.meta.defaults,{...p,draws:2000,common_rho:.3,cost_spread:.3,delay_jitter:3}),low=r.samples.filter(s=>s.cost_factor<.85),high=r.samples.filter(s=>s.cost_factor>1.15),avg=(a,k)=>a.reduce((s,x)=>s+x[k],0)/a.length;assert.ok(avg(high,'payers')<avg(low,'payers'));assert.ok(avg(high,'delay')>avg(low,'delay'));assert.ok(r.samples.every(s=>s.cost_factor>=.7&&s.cost_factor<=1.3));
});
test('Timing clips at bounds, includes late extras and extends regular costs without truncating recovery',()=>{
  const o=deterministic({delay:24,fixed_months:60,extra_costs:[{label:'End',month:84,amount:999}]}),r=MC.run(certain,o,{...p,draws:300,delay_jitter:6});assert.equal(r.horizon,84);assert.ok(r.samples.every(s=>s.delay>=18&&s.delay<=24));for(const s of r.samples){const ref=NPL.evaluate(certain,{...o,delay:s.delay});close(s.gross,ref.gross_total);close(s.cost_total,ref.cost_total);close(s.npv,ref.npv);}
});
test('Capital loss is distinct from negative NPV; sustained payback can fail after later outflows',()=>{
  const probe=NPL.evaluate(certain,deterministic({cost_mode:'simple'})),o=deterministic({cost_mode:'simple',price:(probe.max_price+probe.gross_total*(1-probe.options.cost_rate)-probe.options.startup)/2}),r=MC.run(certain,o,{...p,draws:1});assert.equal(r.probabilities.negative_npv.value,1);assert.equal(r.probabilities.capital_loss.value,0);assert.ok(r.samples[0].payback!==null);
  const late=MC.run(certain,deterministic({price:100,extra_costs:[{label:'Later',month:84,amount:1e7}]}),{...p,draws:1});assert.equal(late.samples[0].payback,null);assert.equal(late.probabilities.payback.value,0);
});
test('Probability intervals, ordered fan quantiles, complete histograms and CSV reconcile to exact samples',()=>{
  const r=MC.run(d.loans,d.meta.defaults,{draws:500,seed:200});for(const [key,field] of [['negative_npv','npv'],['capital_loss','profit']]){const pr=r.probabilities[key];assert.equal(pr.hits,r.samples.filter(s=>s[field]<-1e-7).length);assert.ok(pr.ci95[0]<=pr.value&&pr.value<=pr.ci95[1]);}
  r.curves.forEach(c=>assert.ok(c.p05<=c.p10&&c.p10<=c.p50&&c.p50<=c.p90&&c.p90<=c.p95));assert.equal(r.curves.length,r.horizon+1);for(const h of Object.values(r.histograms))assert.equal(h.reduce((s,b)=>s+b.count,0),500);assert.equal(r.histograms.npv.reduce((s,b)=>s+b.negative_count,0),r.samples.filter(s=>s.npv<0).length);const csv=MC.csv(r);assert.equal(csv.split('\r\n').length,501);assert.ok(csv.includes(String(r.samples[0].npv)));assert.equal(JSON.stringify(r).includes('loan_id'),false);
});
test('Invalid or excessive runs fail before allocating simulation output',()=>{
  for(const bad of [{draws:0},{draws:20001},{seed:-1},{common_rho:.7},{borrower_share:1.1},{amount_spread:NaN},{cost_spread:.9},{delay_jitter:1.5}])assert.throws(()=>MC.run(certain,d.meta.defaults,bad));assert.throws(()=>MC.validate({draws:20000},50000));
});
console.log(count+' Monte Carlo checks passed');
