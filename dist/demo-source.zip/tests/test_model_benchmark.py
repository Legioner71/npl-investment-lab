import copy
import importlib.util
import json
import math
import sys
import unittest
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'python'))
from model_benchmark import (split_samples, metrics, select_champion, benchmark,
                             load_candidate, score_case, digest)

DEPENDENCIES = all(importlib.util.find_spec(x) for x in ('catboost', 'tabpfn'))


@unittest.skipUnless(DEPENDENCIES, 'Run in requirements-benchmark.txt environment')
class BenchmarkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.history = json.loads((ROOT/'dist/benchmark-history.json').read_text())
        cls.case = json.loads((ROOT/'dist/prepurchase-case.json').read_text())
        cls.bundle = json.loads((ROOT/'dist/model-bundle.json').read_text())
        cls.report = json.loads((ROOT/'dist/model-comparison.json').read_text())
        cls.groups, cls.audit = split_samples(cls.history)
        # Also exercise loading actual persisted artifacts, not just fitted objects.
        cls.models = {k: load_candidate(v) for k, v in cls.bundle['models'].items()}

    def small_case(self):
        ids = {s['loan_id'] for s in self.case['snapshots'] if s['quality']=='ready' and s['history_complete']}
        ids = set(sorted(ids)[:2])
        return {'snapshots': [copy.deepcopy(s) for s in self.case['snapshots'] if s['loan_id'] in ids],
                'payments': [copy.deepcopy(p) for p in self.case['payments'] if p['loan_id'] in ids]}

    def test_four_phases_disjoint_and_labels_mature_before_next_phase(self):
        seen, portfolios = set(), set()
        previous = None
        for name in ('train', 'calibration', 'selection', 'test'):
            rows = self.groups[name]
            borrowers = {s['snapshot']['borrower_id'] for s in rows}
            ids = {s['snapshot']['portfolio_id'] for s in rows}
            self.assertFalse(borrowers & seen); self.assertFalse(ids & portfolios)
            if previous:
                self.assertLess(max(s['label_available_at'] for s in previous),
                                min(__import__('datetime').date.fromisoformat(s['snapshot']['as_of_date']) for s in rows))
            seen |= borrowers; portfolios |= ids; previous = rows
        self.assertEqual([len(self.groups[k]) for k in ('train','calibration','selection','test')], [1600,1600,576,960])
        self.assertEqual(self.audit['purged_borrowers'], 64)
        self.assertEqual(self.audit['excluded']['incomplete_outcome'], 120)

    def test_portfolio_error_cannot_cancel_between_portfolios(self):
        rows=[{'y':1,'gross':100.,'basis':100.,'snapshot':{'portfolio_id':'A','seller_id':'S'}},
              {'y':0,'gross':0.,'basis':100.,'snapshot':{'portfolio_id':'B','seller_id':'S'}}]
        result=metrics(rows,np.array([0.,1.]),np.array([1.,1.]))
        self.assertEqual(result['gross_error_fraction'],0.)
        self.assertEqual(result['portfolio_wape'],2.)
        self.assertEqual(result['overestimate_fraction'],1.)
        json.dumps(result,allow_nan=False)

    def test_champion_matches_selection_only(self):
        validation={m['key']:m['selection'] for m in self.report['models']}
        self.assertEqual(select_champion(validation),self.report['selection_champion'])
        # Smaller test error need not belong to the candidate chosen before test.
        self.assertNotEqual(min(self.report['models'],key=lambda m:m['test']['portfolio_wape'])['key'],self.report['selection_champion'])

    def test_current_coverage_is_identical_and_unknowns_remain_null(self):
        coverage=[]
        for m in self.report['models']:
            current=m['current']; rows=current['scores']
            coverage.append([(s['loan_id'],s['status']) for s in rows])
            self.assertEqual((current['scored'],current['total']),(1090,1200))
            self.assertAlmostEqual(current['expected_gross'],sum(s['expected'] or 0 for s in rows))
            for s in rows:
                if s['status']=='scored':
                    self.assertTrue(0<s['probability']<1 and 0<=s['expected']<=s['conditional'])
                else:
                    self.assertIsNone(s['probability']);self.assertIsNone(s['expected'])
        self.assertEqual(coverage[0],coverage[1]);self.assertEqual(coverage[1],coverage[2])
        self.assertEqual(digest(self.case),self.report['case_sha256'])

    def test_persisted_models_reproduce_predictions_for_new_cli_scoring(self):
        package=self.small_case()
        for key, model in self.models.items():
            actual=score_case(model,package)
            saved={s['loan_id']:s for m in self.report['models'] if m['key']==key for s in m['current']['scores']}
            for s in actual['scores']:
                for field in ('probability','conditional','expected'):
                    self.assertTrue(math.isclose(s[field],saved[s['loan_id']][field],rel_tol=2e-5,abs_tol=.02), (key,field,s,saved[s['loan_id']]))

    def test_future_and_late_recorded_events_never_change_any_candidate_score(self):
        original=self.small_case();changed=copy.deepcopy(original)
        for s in changed['snapshots']:
            changed['payments'].extend([
                {'loan_id':s['loan_id'],'payment_date':'2026-12-01','available_at':'2026-12-01','amount':999999},
                {'loan_id':s['loan_id'],'payment_date':'2026-10-01','available_at':'2026-12-01','amount':999999}])
        for key, model in self.models.items():
            a=score_case(model,original);b=score_case(model,changed)
            for left,right in zip(a['scores'],b['scores']):
                for field in ('probability','conditional','expected'):
                    self.assertAlmostEqual(left[field],right[field],places=5,msg=(key,field))

    def test_tampered_artifact_is_rejected(self):
        artifact=copy.deepcopy(self.bundle['models']['baseline']);artifact['calibration']['intercept']+=1
        with self.assertRaisesRegex(ValueError,'checksum'):load_candidate(artifact)

    def test_test_outcomes_cannot_change_fit_calibration_or_selection(self):
        modified=copy.deepcopy(self.history)
        dates={s['loan_id']:s['as_of_date'] for s in modified['snapshots']}
        for p in modified['payments']:
            if '2025-07-01'<=dates[p['loan_id']]<='2025-09-30' and p['payment_date']>dates[p['loan_id']]:
                p['amount']*=.5
        before,bundle_before=benchmark(self.history,self.small_case(),candidates=('baseline','catboost'))
        after,bundle_after=benchmark(modified,self.small_case(),candidates=('baseline','catboost'))
        self.assertEqual(before['selection_champion'],after['selection_champion'])
        self.assertEqual(bundle_before['models'],bundle_after['models'])
        for a,b in zip(before['models'],after['models']):
            self.assertEqual(a['selection'],b['selection'])
            self.assertEqual(a['current'],b['current'])
            self.assertNotEqual(a['test']['actual_gross'],b['test']['actual_gross'])


if __name__=='__main__':unittest.main()
