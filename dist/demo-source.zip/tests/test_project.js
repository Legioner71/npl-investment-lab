'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..'),read=n=>JSON.parse(fs.readFileSync(path.join(root,'dist',n),'utf8'));
const N=require('../dist/engine.js'),P=require('../dist/project-engine.js'),MC=require('../dist/monte-carlo.js');
const model=read('prepurchase-model.json'),pack=read('prepurchase-case.json'),ops=read('strategy-operations.json'),demo=read('demo.json');
const near=(a,b,tol=1e-6)=>assert.ok(Math.abs(a-b)<=tol,`${a} != ${b}`);
const project=P.fromPackage(pack,{name:'Shared project',options:demo.meta.defaults,operations:ops});
const r=P.evaluate(project,model);
assert.equal(r.collection_months,12);assert.equal(r.unknown_count,136);assert.equal(r.count,1200);
near(r.payers,r.project_context.forecast.expected_payers);near(r.gross_total,r.project_context.forecast.expected_gross);
for(const row of r.records){const f=r.project_context.forecast.scores.find(f=>f.loan_id===row.loan_id);if(f.status==='scored'){near(f.probability,row.probability);near(f.expected,row.gross);}else{assert.equal(f.expected,null);assert.equal(row.estimated,false);}}
assert.equal(r.gross.slice(12).reduce((s,v)=>s+v,0),0);assert.ok(r.costs.slice(12).some(v=>v>0));
const sim=MC.run(project.rows,r.options,{draws:200,seed:17});near(sim.base.payers,r.payers);near(sim.base.npv,r.npv);near(sim.base.gross,r.gross_total);assert.equal(sim.ready_count,r.ready_count);
// Imported CSV cannot silently reuse demo history or operational permissions.
const csv=P.create(project.rows,{date:project.as_of_date,options:project.options});const sr=P.evaluate(csv,model);assert.equal(sr.collection_months,36);assert.equal(sr.project_context.source,'scenario');assert.equal(csv.operations.accounts.length,0);
assert.ok(sr.project_context.plans.plans.every(plan=>plan.weeks.flatMap(w=>w.tasks).every(t=>!['plan_support','voluntary_offer'].includes(t.route))));
assert.throws(()=>P.evaluate({...csv,source:'ml'},model));
assert.throws(()=>P.evaluate({...project,rows:project.rows.slice(1)},model));
// Strategy replacement, cap and the finance/simulation identity.
const applied={...project,applied_profile:'capacity'};const ar=P.evaluate(applied,model),plan=ar.project_context.plans.plans.find(p=>p.profile==='capacity');
near(ar.gross_total-r.gross_total,plan.totals.incremental_gross);
near(ar.records.reduce((s,v)=>s+v.contribution,0)-ar.shared_pv,ar.max_price);
for(const rec of ar.records){const loan=project.rows.find(v=>v.loan_id===rec.loan_id);assert.ok(rec.conditional<=loan.principal+loan.interest+loan.penalty-loan.excluded_amount+1e-7);}
const rerun=P.evaluate(applied,model);near(rerun.gross_total,ar.gross_total);near(rerun.cost_total,ar.cost_total);
const as=MC.run(project.rows,ar.options,{draws:20,seed:13});near(as.base.npv,ar.npv);near(as.base.gross,ar.gross_total);
// Deterministic contracts: zero-uncertainty simulation must reproduce full DCF including strategy cash timing.
const certain=structuredClone(ar.options);certain.loan_forecast=certain.loan_forecast.map(v=>v.status==='scored'?{...v,probability:1}:v);
const cr=N.evaluate(project.rows,certain),cs=MC.run(project.rows,certain,{draws:2,seed:5,common_rho:0,borrower_share:0,amount_spread:0,cost_spread:0,delay_jitter:0});near(cs.metrics.npv.mean,cr.npv);near(cs.metrics.gross.mean,cr.gross_total);near(cs.metrics.cost_total.mean,cr.cost_total);
// Freezing does not change when the live price changes; sparse actuals are not zeros.
const frozen=P.freeze(project,r),snapshot=JSON.stringify(frozen.frozen);frozen.options.price+=100000;near(P.evaluate(frozen,model).npv,r.npv-100000);assert.equal(JSON.stringify(frozen.frozen),snapshot);
frozen.actuals=P.validateActuals([{month:3,gross:100,cost:20}],r.gross.length);assert.equal(frozen.actuals.length,1);assert.equal(frozen.actuals[0].month,3);
const restored=P.validateProject(JSON.parse(JSON.stringify(frozen)),model);assert.equal(restored.frozen.fingerprint,r.project_context.fingerprint);
assert.throws(()=>P.validateActuals([{month:1,gross:1,cost:0},{month:1,gross:2,cost:0}],12));
const tamper=structuredClone(frozen);tamper.frozen.result.gross[0]+=1;assert.throws(()=>P.validateProject(tamper,model));
const rounding=structuredClone(frozen);rounding.frozen.result.gross[0]+=1e-10;P.validateProject(rounding,model);
assert.equal(P.hash({amount:12345.123456789}),P.hash({amount:12345.123456789+1e-11}));
console.log('Project integration checks passed: shared forecasts, MC, strategy, unknowns, frozen baseline and restore.');
