import copy
import json
import math
import subprocess
import sys
import unittest
from datetime import date
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))
from prepurchase import feature_row, score_package, build_samples, temporal_split, horizon_end, train_package

class PrepurchaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.case=json.loads((ROOT/'dist/prepurchase-case.json').read_text())
        cls.history=json.loads((ROOT/'dist/prepurchase-history.json').read_text())
        cls.model=json.loads((ROOT/'dist/prepurchase-model.json').read_text())

    def valid_case(self):
        snapshot=next(s for s in self.case['snapshots'] if s['quality']=='ready' and s['history_complete'])
        return {'snapshots':[copy.deepcopy(snapshot)],'payments':[copy.deepcopy(p) for p in self.case['payments'] if p['loan_id']==snapshot['loan_id']]}

    def test_future_events_never_change_features_or_scores(self):
        case=self.valid_case();before=score_package(self.model,case)
        s=case['snapshots'][0]
        case['payments'].append({'loan_id':s['loan_id'],'payment_date':'2026-11-01','available_at':'2026-11-01','amount':99999999})
        case['payments'].append({'loan_id':s['loan_id'],'payment_date':'2026-10-01','available_at':'2026-11-01','amount':99999999})
        after=score_package(self.model,case)
        self.assertEqual(before,after)

    def test_unknown_history_is_not_zero_payment(self):
        case=self.valid_case();case['snapshots'][0]['history_complete']=False
        r=score_package(self.model,case)['scores'][0]
        self.assertEqual(r['status'],'history_unknown');self.assertIsNone(r['probability'])

    def test_review_case_has_no_prediction(self):
        case=self.valid_case();case['snapshots'][0]['quality']='review'
        r=score_package(self.model,case)['scores'][0]
        self.assertEqual(r['status'],'legal_review');self.assertIsNone(r['expected'])

    def test_incomplete_outcomes_are_censored_not_labelled_zero(self):
        samples,excluded=build_samples(self.history)
        self.assertEqual(excluded['incomplete_outcome'],120)
        self.assertTrue(all(s['snapshot']['as_of_date']<'2026-01-01' for s in samples))

    def test_labels_available_and_borrowers_purged(self):
        samples,_=build_samples(self.history)
        train,cal,test,counts=temporal_split(samples,self.history['meta']['split'])
        groups=[{s['snapshot']['borrower_id'] for s in a} for a in (train,cal,test)]
        self.assertFalse(groups[0]&groups[1] or groups[0]&groups[2] or groups[1]&groups[2])
        self.assertEqual(counts['purged_borrowers'],64)
        self.assertLess(max(s['label_available_at'] for s in train),min(date.fromisoformat(s['snapshot']['as_of_date']) for s in cal))
        self.assertLess(max(s['label_available_at'] for s in cal),min(date.fromisoformat(s['snapshot']['as_of_date']) for s in test))

    def test_bad_join_duplicate_and_negative_amount_rejected(self):
        for mutate in (lambda c:c['snapshots'].append(c['snapshots'][0]),
                       lambda c:c['payments'].append({'loan_id':'unknown','payment_date':'2026-01-01','available_at':'2026-01-01','amount':1}),
                       lambda c:c['payments'].append({'loan_id':c['snapshots'][0]['loan_id'],'payment_date':'2026-01-01','available_at':'2026-01-01','amount':-1})):
            c=self.valid_case();mutate(c)
            with self.assertRaises(ValueError):score_package(self.model,c)

    def test_predictions_are_bounded_and_aggregate_reconciles(self):
        r=score_package(self.model,self.case);known=[s for s in r['scores'] if s['status']=='scored']
        self.assertEqual(r['scored'],1090)
        self.assertAlmostEqual(r['expected_gross'],sum(s['expected'] for s in known))
        self.assertTrue(all(0<s['probability']<1 and 0<=s['expected']<=s['conditional'] for s in known))

    def test_python_browser_parity(self):
        script="const p=require('./dist/prepurchase-engine.js');const m=require('./dist/prepurchase-model.json');const c=require('./dist/prepurchase-case.json');console.log(JSON.stringify(p.scorePackage(m,c)));"
        browser=json.loads(subprocess.check_output(['node','-e',script],cwd=ROOT))
        python=score_package(self.model,self.case)
        def compare(a,b):
            if isinstance(a,dict):
                self.assertEqual(set(a),set(b))
                for k in a:compare(a[k],b[k])
            elif isinstance(a,list):
                self.assertEqual(len(a),len(b))
                for x,y in zip(a,b):compare(x,y)
            elif isinstance(a,(int,float)):
                self.assertTrue(math.isclose(a,b,abs_tol=1e-7,rel_tol=1e-10),(a,b))
            else:self.assertEqual(a,b)
        compare(python,browser)

    def test_leap_year_horizon(self):
        self.assertEqual(horizon_end(date(2024,2,29)),date(2025,2,28))

    def test_corrupt_model_is_rejected(self):
        m=copy.deepcopy(self.model);m['scale'][0]=0
        with self.assertRaises(ValueError):score_package(m,self.valid_case())

    def test_test_outcomes_never_train_model(self):
        modified=copy.deepcopy(self.history)
        dates={s['loan_id']:s['as_of_date'] for s in modified['snapshots']}
        for p in modified['payments']:
            if '2025-07-01'<=dates[p['loan_id']]<='2025-09-30' and p['payment_date']>dates[p['loan_id']]:
                p['amount']*=.5
        model,report=train_package(modified)
        self.assertEqual(model,self.model)
        self.assertNotAlmostEqual(report['metrics']['actual_gross'],json.loads((ROOT/'dist/prepurchase-validation.json').read_text())['metrics']['actual_gross'])

if __name__=='__main__':unittest.main()
