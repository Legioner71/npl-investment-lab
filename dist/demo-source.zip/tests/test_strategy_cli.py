import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))
from prepurchase import score_package
from strategy import calculate

class StrategyCLITests(unittest.TestCase):
    def test_python_entry_point_runs_shared_engine_and_reconciles(self):
        case=json.loads((ROOT/'dist/prepurchase-case.json').read_text())
        model=json.loads((ROOT/'dist/prepurchase-model.json').read_text())
        forecast=score_package(model,case)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'forecast.json';path.write_text(json.dumps(forecast))
            result=calculate(ROOT/'dist/prepurchase-case.json',ROOT/'dist/strategy-operations.json',path)
        self.assertEqual(len(result['plans']),3)
        for plan in result['plans']:
            self.assertEqual(sum(w['days'] for w in plan['weeks']),90)
            self.assertAlmostEqual(plan['totals']['cost'],sum(w['cost'] for w in plan['weeks']))
            self.assertTrue(plan['budget']['feasible'])
            self.assertEqual(plan['coverage']['total'],1200)

if __name__=='__main__':unittest.main()
