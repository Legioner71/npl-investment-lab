"""Reproducible comparison of two-part baseline, CatBoost and local TabPFN v2.

Four chronological, borrower-disjoint phases: train, calibrate, select, final test.
The selection criterion is portfolio WAPE on selection only. Test labels never fit
models, calibration, hyperparameters or the champion. All settings are fixed.
TabPFN weights are downloaded from the official public v2 repository; no API is used.
"""
import argparse
import hashlib
import importlib.metadata
import json
import os
import tempfile
import time
from collections import defaultdict
from pathlib import Path

os.environ.setdefault('TABPFN_DISABLE_TELEMETRY', '1')
os.environ.setdefault('TABPFN_ALLOW_CPU_LARGE_DATASET', '1')

import numpy as np
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import roc_auc_score, brier_score_loss, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from prepurchase import FEATURES, build_samples, day, feature_row, horizon_end, payment_index, validate_package

SEED = 20261028
NAMES = {'baseline': 'Logistic + Ridge', 'catboost': 'CatBoost', 'tabpfn': 'TabPFN v2'}
SETTINGS = {
    'baseline': {'classifier_C': 1., 'amount_alpha': 10.},
    'catboost': {'iterations': 250, 'depth': 4, 'learning_rate': .035, 'l2_leaf_reg': 8.},
    'tabpfn': {'n_estimators': 1, 'device': 'cpu', 'fit_mode': 'fit_with_cache', 'batch_size': 128}}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def split_samples(package):
    samples, excluded = build_samples(package)
    c = package['meta']['comparison_split']
    keys = ['train_end', 'calibration_start', 'calibration_end', 'selection_start', 'selection_end', 'test_start', 'test_end']
    a, b, d, e, f, g, h = [day(c[k]) for k in keys]
    if not a < b <= d < e <= f < g <= h:
        raise ValueError('Four chronological phases required')
    ranges = [(None, a, b), (b, d, e), (e, f, g), (g, h, None)]
    seen, portfolios_seen, groups, purged = set(), set(), {}, 0
    for name, (start, end, next_start) in zip(('train', 'calibration', 'selection', 'test'), ranges):
        candidates = [s for s in samples if (start is None or day(s['snapshot']['as_of_date']) >= start)
                      and day(s['snapshot']['as_of_date']) <= end
                      and (next_start is None or s['label_available_at'] < next_start)]
        rows = [s for s in candidates if s['snapshot']['borrower_id'] not in seen]
        purged += len(candidates)-len(rows)
        if len(rows) < 40 or len({s['y'] for s in rows}) != 2:
            raise ValueError('At least 40 rows and both classes needed in '+name)
        portfolio_ids = {s['snapshot']['portfolio_id'] for s in rows}
        if portfolio_ids & portfolios_seen: raise ValueError('Portfolio occurs in multiple phases')
        seen.update(s['snapshot']['borrower_id'] for s in rows)
        portfolios_seen.update(portfolio_ids)
        groups[name] = rows
    audit = {name: {'count': len(rows), 'portfolios': len({s['snapshot']['portfolio_id'] for s in rows}),
                   'as_of_start': min(s['snapshot']['as_of_date'] for s in rows),
                   'as_of_end': max(s['snapshot']['as_of_date'] for s in rows),
                   'labels_available_until': max(s['label_available_at'] for s in rows).isoformat(),
                   'loan_ids_sha256': digest(sorted(s['snapshot']['loan_id'] for s in rows))}
             for name, rows in groups.items()}
    return groups, {'phases': audit, 'excluded': excluded, 'purged_borrowers': purged, 'split': c}


def matrix(rows):
    return np.asarray([s['x'] for s in rows], dtype=np.float64)


def new_tabpfn(kind):
    import torch
    from tabpfn import TabPFNClassifier, TabPFNRegressor
    torch.set_num_threads(4)
    cls = TabPFNClassifier if kind == 'classifier' else TabPFNRegressor
    # Explicit public v2 filenames avoid gated defaults in future SDK releases.
    name = 'tabpfn-v2-classifier-finetuned-zk73skhh.ckpt' if kind == 'classifier' else 'tabpfn-v2-regressor.ckpt'
    return cls(device='cpu', n_estimators=1, random_state=SEED, n_jobs=1,
               fit_mode='fit_with_cache', model_path=Path.home()/'.cache/tabpfn'/name)


class Candidate:
    def __init__(self, key):
        self.key = key
        self.scaler = None
        self.calibration = None

    def fit(self, train):
        x = matrix(train); y = np.asarray([s['y'] for s in train]); pos = y == 1
        fractions = np.asarray([s['fraction'] for s in train])
        if self.key == 'baseline':
            self.scaler = StandardScaler().fit(x)
            x = self.scaler.transform(x)
            self.classifier = LogisticRegression(C=1., max_iter=2000, random_state=SEED)
            self.amount = Ridge(alpha=10.)
        elif self.key == 'catboost':
            from catboost import CatBoostClassifier, CatBoostRegressor
            config = dict(**SETTINGS['catboost'], random_seed=SEED, thread_count=4,
                          verbose=False, allow_writing_files=False)
            self.classifier = CatBoostClassifier(**config, loss_function='Logloss')
            self.amount = CatBoostRegressor(**config, loss_function='RMSE')
        elif self.key == 'tabpfn':
            self.classifier = new_tabpfn('classifier'); self.amount = new_tabpfn('regressor')
        else: raise ValueError('Unknown candidate')
        self.classifier.fit(x, y)
        self.amount.fit(x[pos], fractions[pos])
        self.training = {'x': matrix(train).tolist(), 'y': y.tolist(), 'fraction': fractions.tolist()}
        self.sellers = sorted({s['snapshot']['seller_id'] for s in train})
        return self

    def raw_predict(self, x):
        if not len(x): return np.empty(0), np.empty(0)
        if self.scaler is not None: x = self.scaler.transform(x)
        batch = SETTINGS['tabpfn']['batch_size'] if self.key == 'tabpfn' else len(x)
        ps, rs = [], []
        for start in range(0, len(x), batch):
            chunk = x[start:start+batch]
            ps.extend(self.classifier.predict_proba(chunk)[:, 1])
            rs.extend(self.amount.predict(chunk))
        p = np.clip(np.asarray(ps), 1e-7, 1-1e-7)
        r = np.clip(np.asarray(rs), 0., 1.)
        if not np.isfinite(p).all() or not np.isfinite(r).all(): raise ValueError('Non-finite prediction')
        return p, r

    def calibrate(self, rows):
        p, _ = self.raw_predict(matrix(rows))
        logits = np.log(p/(1-p)).reshape(-1, 1)
        c = LogisticRegression(C=1000., max_iter=2000).fit(logits, [s['y'] for s in rows])
        self.calibration = {'intercept': float(c.intercept_[0]), 'coefficient': float(c.coef_[0, 0])}
        return self

    def predict(self, x):
        p, r = self.raw_predict(x)
        z = self.calibration['intercept'] + self.calibration['coefficient'] * np.log(p/(1-p))
        return 1/(1+np.exp(-np.clip(z, -40, 40))), r

    def export(self):
        out = {'key': self.key, 'settings': SETTINGS[self.key], 'calibration': self.calibration,
               'training_sellers': self.sellers}
        if self.key == 'baseline':
            out.update(mean=self.scaler.mean_.tolist(), scale=self.scaler.scale_.tolist(),
                classifier={'intercept': float(self.classifier.intercept_[0]), 'coefficients': self.classifier.coef_[0].tolist()},
                amount={'intercept': float(self.amount.intercept_), 'coefficients': self.amount.coef_.tolist()})
        elif self.key == 'catboost':
            with tempfile.TemporaryDirectory() as tmp:
                for key in ('classifier', 'amount'):
                    p = Path(tmp)/(key+'.json'); getattr(self, key).save_model(str(p), format='json')
                    value = json.loads(p.read_text())
                    # Training timestamps/run GUIDs are irrelevant for inference and reproducibility.
                    value.get('model_info', {}).pop('train_finish_time', None)
                    value.get('model_info', {}).pop('model_guid', None)
                    out[key] = value
        else:
            out['context'] = self.training
            out['checkpoints'] = []
            for kind in ('classifier', 'regressor'):
                filename = 'tabpfn-v2-classifier-finetuned-zk73skhh.ckpt' if kind == 'classifier' else 'tabpfn-v2-regressor.ckpt'
                p = Path.home()/'.cache/tabpfn'/filename
                out['checkpoints'].append({'filename': filename, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
        out['artifact_id'] = digest(out)[:16]
        return out


def metrics(rows, p, ratios):
    y = np.asarray([s['y'] for s in rows]); actual = np.asarray([s['gross'] for s in rows])
    expected = p*ratios*np.asarray([s['basis'] for s in rows])
    aggregates = defaultdict(lambda: [0., 0., 0])
    sellers = defaultdict(lambda: [0., 0., 0])
    for s, estimate in zip(rows, expected):
        for table, key in ((aggregates, s['snapshot']['portfolio_id']), (sellers, s['snapshot']['seller_id'])):
            table[key][0] += float(estimate); table[key][1] += s['gross']; table[key][2] += 1
    portfolio_rows = [{'portfolio_id': k, 'predicted': v[0], 'actual': v[1], 'count': v[2]} for k, v in sorted(aggregates.items())]
    total = float(actual.sum())
    groups = []
    for ix in np.array_split(np.argsort(p), min(10, len(rows))):
        groups.append({'count': len(ix), 'predicted': float(p[ix].mean()), 'observed': float(y[ix].mean())})
    return {'auc': float(roc_auc_score(y, p)), 'brier': float(brier_score_loss(y, p)),
            'mae_money': float(mean_absolute_error(actual, expected)),
            'predicted_gross': float(expected.sum()), 'actual_gross': total,
            'gross_error_fraction': float((expected.sum()-total)/total) if total else None,
            'portfolio_wape': float(sum(abs(v[0]-v[1]) for v in aggregates.values())/total) if total else None,
            'overestimate_fraction': float(sum(max(0, v[0]-v[1]) for v in aggregates.values())/total) if total else None,
            'expected_payers': float(p.sum()), 'actual_payers': int(y.sum()),
            'calibration_bins': groups, 'portfolios': portfolio_rows,
            'sellers': [{'seller_id': k, 'predicted': v[0], 'actual': v[1], 'count': v[2],
                         'gross_error_fraction': (v[0]-v[1])/v[1] if v[1] else None} for k, v in sorted(sellers.items())]}


def select_champion(validation_results):
    # The signature deliberately cannot access test results.
    return min(validation_results, key=lambda k: (validation_results[k]['portfolio_wape'], validation_results[k]['mae_money'], k))


def prepare_case(package):
    snapshots, payments = validate_package(package)
    index = payment_index(payments); prepared, eligible = [], []
    for s in snapshots:
        x, reason = feature_row(s, index[s['loan_id']])
        basis = s['principal']+s['interest']+s['penalty']-s['excluded_amount']
        prepared.append({'snapshot': s, 'x': x, 'reason': reason, 'basis': basis})
        if x is not None: eligible.append(prepared[-1])
    return prepared, eligible


def score_case(candidate, package):
    rows, known = prepare_case(package)
    p, ratios = candidate.predict(np.asarray([s['x'] for s in known], dtype=float).reshape(-1, len(FEATURES)))
    predictions = {s['snapshot']['loan_id']: (float(a), float(b)) for s, a, b in zip(known, p, ratios)}
    out = []
    for row in rows:
        s = row['snapshot']; pair = predictions.get(s['loan_id'])
        out.append({'loan_id': s['loan_id'], 'segment': s['segment'], 'as_of_date': s['as_of_date'],
                    'horizon_end': horizon_end(day(s['as_of_date'])).isoformat(),
                    'status': row['reason'] or 'scored', 'unseen_seller': s['seller_id'] not in candidate.sellers,
                    'probability': pair[0] if pair else None,
                    'conditional': pair[1]*row['basis'] if pair else None,
                    'expected': pair[0]*pair[1]*row['basis'] if pair else None})
    return {'scored': len(known), 'total': len(rows), 'expected_payers': float(p.sum()),
            'expected_gross': sum(s['expected'] or 0 for s in out), 'scores': out}


def benchmark(history, case, candidates=('baseline', 'catboost', 'tabpfn')):
    groups, audit = split_samples(history)
    report = {'schema_version': 1, 'synthetic': history['meta'].get('synthetic') is True,
              'horizon_months': 12, 'features': FEATURES, 'audit': audit, 'case_sha256': digest(case),
              'selection_metric': 'portfolio_wape', 'candidate_settings_fixed': True,
              'versions': {name: importlib.metadata.version(name) for name in ('numpy', 'scikit-learn', 'catboost', 'tabpfn', 'torch')},
              'models': []}
    bundle = {'schema_version': 1, 'features': FEATURES, 'horizon_months': 12,
              'synthetic_training': report['synthetic'], 'models': {}}
    fitted = {}; validation = {}
    # Fit and choose the champion BEFORE any final test scoring.
    for key in candidates:
        start = time.monotonic(); print('Fit/calibrate/select: '+key, flush=True)
        model = Candidate(key).fit(groups['train']).calibrate(groups['calibration'])
        p, r = model.predict(matrix(groups['selection']))
        validation[key] = metrics(groups['selection'], p, r)
        fitted[key] = model
        artifact = model.export(); bundle['models'][key] = artifact
        report['models'].append({'key': key, 'name': NAMES[key], 'artifact_id': artifact['artifact_id'],
            'settings': SETTINGS[key], 'selection': validation[key], 'fit_calibrate_select_seconds': time.monotonic()-start})
        print('Selection '+key+': '+json.dumps({k: validation[key][k] for k in ('auc','brier','portfolio_wape')}), flush=True)
    report['selection_champion'] = select_champion(validation)
    bundle['selection_champion'] = report['selection_champion']
    for row in report['models']:
        key = row['key']; print('Final test/current case: '+key, flush=True)
        p, r = fitted[key].predict(matrix(groups['test']))
        row['test'] = metrics(groups['test'], p, r)
        row['current'] = score_case(fitted[key], case)
    report['benchmark_id'] = digest({'audit': audit, 'artifacts': {k: v['artifact_id'] for k, v in bundle['models'].items()},
                                     'case': report['case_sha256']})[:16]
    bundle['benchmark_id'] = report['benchmark_id']
    return report, bundle


def load_candidate(artifact):
    expected_id = artifact.get('artifact_id')
    if expected_id != digest({k:v for k,v in artifact.items() if k != 'artifact_id'})[:16]:
        raise ValueError('Model artifact checksum mismatch')
    if artifact.get('key') not in NAMES or artifact.get('settings') != SETTINGS[artifact['key']]:
        raise ValueError('Unsupported candidate settings')
    if not all(type(artifact['calibration'][k]) in (int, float) and np.isfinite(artifact['calibration'][k]) for k in ('intercept', 'coefficient')):
        raise ValueError('Invalid calibrator')
    key = artifact['key']; model = Candidate(key)
    model.calibration = artifact['calibration']; model.sellers = artifact['training_sellers']
    if key == 'baseline':
        model.scaler = StandardScaler(); model.scaler.mean_ = np.asarray(artifact['mean']); model.scaler.scale_ = np.asarray(artifact['scale'])
        model.scaler.var_ = model.scaler.scale_**2; model.scaler.n_features_in_ = len(FEATURES)
        c = LogisticRegression(); c.classes_ = np.array([0, 1]); c.coef_ = np.array([artifact['classifier']['coefficients']]); c.intercept_ = np.array([artifact['classifier']['intercept']]); c.n_features_in_ = len(FEATURES)
        r = Ridge(); r.coef_ = np.array(artifact['amount']['coefficients']); r.intercept_ = artifact['amount']['intercept']; r.n_features_in_ = len(FEATURES)
        model.classifier, model.amount = c, r
    elif key == 'catboost':
        from catboost import CatBoostClassifier, CatBoostRegressor
        with tempfile.TemporaryDirectory() as tmp:
            for name, cls in (('classifier', CatBoostClassifier), ('amount', CatBoostRegressor)):
                p = Path(tmp)/(name+'.json'); p.write_text(json.dumps(artifact[name]))
                setattr(model, name, cls().load_model(str(p), format='json'))
    elif key == 'tabpfn':
        expected_files = {'tabpfn-v2-classifier-finetuned-zk73skhh.ckpt', 'tabpfn-v2-regressor.ckpt'}
        if {e['filename'] for e in artifact['checkpoints']} != expected_files:
            raise ValueError('Unsupported checkpoint')
        context = artifact['context']; x = np.asarray(context['x']); y = np.asarray(context['y']); fraction = np.asarray(context['fraction'])
        model.classifier = new_tabpfn('classifier'); model.amount = new_tabpfn('regressor')
        model.classifier.fit(x, y); model.amount.fit(x[y == 1], fraction[y == 1])
        for entry in artifact['checkpoints']:
            p = Path.home()/'.cache/tabpfn'/entry['filename']
            if hashlib.sha256(p.read_bytes()).hexdigest() != entry['sha256']: raise ValueError('Checkpoint checksum mismatch')
    else: raise ValueError('Unknown model key')
    return model


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); sub = parser.add_subparsers(dest='command', required=True)
    b = sub.add_parser('run'); b.add_argument('history'); b.add_argument('case'); b.add_argument('--report', required=True); b.add_argument('--bundle', required=True)
    s = sub.add_parser('score'); s.add_argument('bundle'); s.add_argument('case'); s.add_argument('--model', choices=NAMES); s.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.command == 'run':
        report, bundle = benchmark(json.loads(Path(args.history).read_text()), json.loads(Path(args.case).read_text()))
        Path(args.report).write_text(json.dumps(report, ensure_ascii=False, allow_nan=False))
        Path(args.bundle).write_text(json.dumps(bundle, ensure_ascii=False, allow_nan=False))
        print(json.dumps({'champion_on_selection': report['selection_champion'], 'benchmark_id': report['benchmark_id']}))
    else:
        bundle = json.loads(Path(args.bundle).read_text()); key = args.model or bundle['selection_champion']
        if bundle['features'] != FEATURES or bundle['horizon_months'] != 12: raise ValueError('Incompatible bundle')
        result = score_case(load_candidate(bundle['models'][key]), json.loads(Path(args.case).read_text()))
        result.update(model=key, model_id=key+'-'+bundle['models'][key]['artifact_id'], horizon_months=12,
                      synthetic_training=bundle['synthetic_training'], artifact_id=bundle['models'][key]['artifact_id'])
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, allow_nan=False))
        print(json.dumps({k:v for k,v in result.items() if k != 'scores'}))
