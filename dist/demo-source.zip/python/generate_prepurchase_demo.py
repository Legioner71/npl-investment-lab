"""Synthetic history with mature outcomes, censored cases and borrower overlaps."""
import json
import math
import random
from datetime import date, timedelta
from pathlib import Path
from prepurchase import feature_row, horizon_end, sigmoid, train_package, score_package

ROOT = Path(__file__).resolve().parents[1]
rng = random.Random(20261028)
SEGS = ("bank_early", "bank_late", "mfo_early", "mfo_late")

def enrich(row, as_of, portfolio, seller, complete=True):
    row = {**row, "as_of_date": as_of.isoformat(), "portfolio_id": portfolio, "seller_id": seller,
           "issued_at": (as_of - timedelta(days=int(row["dpd"]) + rng.randint(45, 240))).isoformat(),
           "history_complete": complete}
    row["history_start_date"] = max(date.fromisoformat(row["issued_at"]), as_of - timedelta(days=180)).isoformat()
    basis = row["principal"] + row["interest"] + row["penalty"] - row["excluded_amount"]
    past = []
    max_days = min(179, (as_of - date.fromisoformat(row["issued_at"])).days - 1)
    for _ in range(rng.randint(0, 8)):
        when = as_of - timedelta(days=rng.randint(1, max_days))
        past.append({"loan_id": row["loan_id"], "payment_date": when.isoformat(),
                     "available_at": (when + timedelta(days=rng.randint(0, 3))).isoformat(),
                     "amount": round(basis * rng.uniform(.005, .055), 2)})
    if rng.random() < .08:
        # Backdated event that was unavailable at cut-off; it must not enter the features.
        past.append({"loan_id": row["loan_id"], "payment_date": (as_of - timedelta(days=2)).isoformat(),
                     "available_at": (as_of + timedelta(days=20)).isoformat(), "amount": round(basis * .2, 2)})
    return row, past

history = {"meta": {"synthetic": True, "extract_as_of": "2026-10-28", "horizon_months": 12,
           "split": {"train_end": "2023-03-31", "calibration_start": "2024-04-01", "calibration_end": "2024-06-30",
                     "test_start": "2025-07-01", "test_end": "2025-09-30"}}, "snapshots": [], "payments": [], "observations": []}
phases = [(1600, 2023, 1), (600, 2024, 4), (1000, 2025, 7), (120, 2026, 1)]
counter = 0
for phase, (count, year, first_month) in enumerate(phases):
    for j in range(count):
        counter += 1
        as_of = date(year, first_month + j % 3, 1)
        segment = SEGS[j % 4]
        bank = segment.startswith("bank")
        principal = round(rng.uniform(9000, 58000) if bank else rng.uniform(2500, 15000), 2)
        row = {"loan_id": f"H-{counter:06d}", "borrower_id": f"H-B-{counter:06d}", "segment": segment,
               "principal": principal, "interest": round(principal * rng.uniform(.08, .35), 2),
               "penalty": round(principal * .08, 2), "excluded_amount": round(principal * .08, 2),
               "dpd": rng.randint(90, 360) if segment.endswith("early") else rng.randint(361, 1600),
               "quality": "ready"}
        if phase in (1, 2) and j % 25 == 0: row["borrower_id"] = f"H-B-{j%1200+1:06d}"
        row, past = enrich(row, as_of, f"P-{year}-{as_of.month:02d}-{j%4}", f"SELLER-{j%4+1}")
        x, _ = feature_row(row, past)
        probability = sigmoid(-1.2 + .95*x[3] + 1.5*x[5] - .60*(x[1]-5.5) + .3*bank)
        ratio = max(.03, min(.95, (.23 + .22*bank + .07*x[3] - .04*(x[1]-5.5)) * rng.lognormvariate(0, .25)))
        basis = principal + row["interest"]
        paid = rng.random() < probability
        future = []
        if paid and phase != 3:
            cents = round(basis * ratio * 100)
            n = rng.randint(1, 5)
            cuts = sorted(rng.sample(range(1, cents), n-1)) if n > 1 else []
            parts = [b-a for a,b in zip([0,*cuts],[*cuts,cents])]
            for part in parts:
                when = as_of + timedelta(days=rng.randint(1, 360))
                future.append({"loan_id": row["loan_id"], "payment_date": when.isoformat(),
                               "available_at": (when + timedelta(days=rng.randint(0, 3))).isoformat(), "amount": part/100})
        end = horizon_end(as_of)
        obs = {"loan_id": row["loan_id"], "complete": phase != 3,
               "observed_until": end.isoformat() if phase != 3 else "2026-10-28",
               "available_at": (end + timedelta(days=7)).isoformat() if phase != 3 else "2026-10-28"}
        history["snapshots"].append(row); history["payments"].extend(past+future); history["observations"].append(obs)

case = {"meta": {"synthetic": True, "extract_as_of": "2026-10-28", "horizon_months": 12}, "snapshots": [], "payments": []}
for i, row in enumerate(json.loads((ROOT / "dist/demo.json").read_text())["loans"]):
    snapshot, past = enrich(row, date(2026, 10, 28), "UA-DEMO-001", f"SELLER-{i%4+1}", i%29 != 0)
    case["snapshots"].append(snapshot); case["payments"].extend(past)

for name, value in (("prepurchase-history.json", history), ("prepurchase-case.json", case)):
    (ROOT / "dist" / name).write_text(json.dumps(value, ensure_ascii=False))
model, report = train_package(history)
(ROOT / "dist/prepurchase-model.json").write_text(json.dumps(model, ensure_ascii=False, indent=2))
(ROOT / "dist/prepurchase-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
scored = score_package(model, case)
print(json.dumps({"history": len(history["snapshots"]), "splits": report["counts"], "excluded": report["excluded"],
                  "current_scored": scored["scored"], "auc_synthetic": report["metrics"]["auc"],
                  "brier_synthetic": report["metrics"]["brier"], "gross_error_synthetic": report["metrics"]["gross_error_fraction"]}))
