"""Evaluate the same unified project as the browser, using the shared JS engine."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project', type=Path)
    parser.add_argument('--model', type=Path, default=ROOT / 'dist/prepurchase-model.json')
    parser.add_argument('--mc-params', type=Path, help='Optional JSON settings: also run Monte Carlo')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    node = shutil.which('node')
    if not node:
        parser.error('Node.js is required for the shared project engine.')
    program = """
const fs=require('node:fs'),P=require(process.argv[1]),N=require(process.argv[2]);
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const model=read(process.argv[4]),project=P.validateProject(read(process.argv[3]),model);
const result=P.evaluate(project,model),out={schema:'npl-project-result-v1',project_id:project.id,result};
if(process.argv[5]){const MC=require(process.argv[5]);out.simulation=MC.run(project.rows,result.options,read(process.argv[6]));}
process.stdout.write(JSON.stringify(out));
"""
    command = [node, '-e', program, str(ROOT/'dist/project-engine.js'), str(ROOT/'dist/engine.js'), str(args.project.resolve()), str(args.model.resolve())]
    if args.mc_params:
        command += [str(ROOT/'dist/monte-carlo.js'), str(args.mc_params.resolve())]
    completed = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
    if completed.returncode:
        parser.error(completed.stderr.strip())
    result = json.loads(completed.stdout)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(args.output)

if __name__ == '__main__':
    main()
