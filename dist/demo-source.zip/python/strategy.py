"""Python CLI for the same strategy engine used in the browser (requires Node.js).

No second financial implementation: the shared JS engine calculates all plans.
Use with a prepurchase score JSON containing horizon_months=12 and all contracts.
"""
import argparse
import json
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def calculate(case_path,operations_path,forecast_path,params_path=None):
    command=['node',str(ROOT/'dist/strategy-engine.js'),str(Path(case_path).resolve()),str(Path(operations_path).resolve()),str(Path(forecast_path).resolve())]
    if params_path:command.append(str(Path(params_path).resolve()))
    result=subprocess.run(command,capture_output=True,text=True,check=False)
    if result.returncode:raise ValueError(result.stderr.strip())
    return json.loads(result.stdout)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case');parser.add_argument('operations');parser.add_argument('forecast')
    parser.add_argument('--params');parser.add_argument('--output',required=True)
    args=parser.parse_args()
    result=calculate(args.case,args.operations,args.forecast,args.params)
    Path(args.output).write_text(json.dumps(result,ensure_ascii=False,allow_nan=False))
    print(json.dumps({'recommendation':result['recommendation'],'profiles':len(result['plans']),'engine':result['engine_version']}))
