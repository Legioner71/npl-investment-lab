"""Synthetic operational flags for the existing synthetic demonstration only."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def generate(case):
    accounts=[]
    for i,s in enumerate(case['snapshots']):
        contact='blocked' if i%17==0 else 'unknown' if i%11==0 else 'allowed'
        accounts.append(dict(loan_id=s['loan_id'],contact_status=contact,rules_verified=contact=='allowed' and i%13!=0,
            active_payment_plan=i%5==0,legal_review_required=s['quality']=='review' or i%43==0,updated_at='2026-10-28'))
    return {'meta':{'synthetic':True,'as_of_date':'2026-10-28','description':'Generated flags, not legal verification of real debtors'},'accounts':accounts}

if __name__=='__main__':
    case=json.loads((ROOT/'dist/prepurchase-case.json').read_text())
    operations=generate(case)
    (ROOT/'dist/strategy-operations.json').write_text(json.dumps(operations,ensure_ascii=False))
    (ROOT/'dist/strategy-input-demo.json').write_text(json.dumps({'case':case,'operations':operations},ensure_ascii=False))
    print('Synthetic operational flags:',len(operations['accounts']))
