"""Add an independent synthetic 2021 training cohort for a four-stage benchmark.

The v0.3 fixtures remain unchanged. This is a simulation, not Ukrainian market data.
"""
import copy
import json
import random
from datetime import date, timedelta
from pathlib import Path
from prepurchase import SEGMENTS, feature_row, horizon_end, sigmoid

ROOT = Path(__file__).resolve().parents[1]


def generate(existing, count=1600):
    package = copy.deepcopy(existing)
    rng = random.Random(20261029)
    package['meta']['comparison_split'] = {
        'train_end': '2021-03-31',
        'calibration_start': '2023-01-01', 'calibration_end': '2023-03-31',
        'selection_start': '2024-04-01', 'selection_end': '2024-06-30',
        'test_start': '2025-07-01', 'test_end': '2025-09-30'}
    for j in range(count):
        cutoff = date(2021, 1 + j % 3, 1)
        segment = SEGMENTS[j % 4]
        bank = segment.startswith('bank')
        principal = round(rng.uniform(9000, 58000) if bank else rng.uniform(2500, 15000), 2)
        dpd = rng.randint(90, 360) if segment.endswith('early') else rng.randint(361, 1600)
        issued = cutoff - timedelta(days=dpd + rng.randint(45, 240))
        s = dict(loan_id=f'BC-{j:06d}', borrower_id=f'BC-B-{j:06d}',
                 portfolio_id=f'BC-P-2021-{cutoff.month:02d}-{j % 4}', seller_id=f'SELLER-{j % 4 + 1}',
                 as_of_date=cutoff.isoformat(), issued_at=issued.isoformat(), segment=segment,
                 principal=principal, interest=round(principal * rng.uniform(.08, .35), 2),
                 penalty=round(principal * .08, 2), excluded_amount=round(principal * .08, 2),
                 dpd=dpd, quality='ready', history_complete=True,
                 history_start_date=max(issued, cutoff - timedelta(days=180)).isoformat())
        basis = principal + s['interest']
        payments = []
        for _ in range(rng.randint(0, 8)):
            when = cutoff - timedelta(days=rng.randint(1, min(179, (cutoff-issued).days-1)))
            payments.append(dict(loan_id=s['loan_id'], payment_date=when.isoformat(),
                                 available_at=(when + timedelta(days=rng.randint(0, 3))).isoformat(),
                                 amount=round(basis*rng.uniform(.005, .055), 2)))
        if rng.random() < .08:
            payments.append(dict(loan_id=s['loan_id'], payment_date=(cutoff-timedelta(days=2)).isoformat(),
                                 available_at=(cutoff+timedelta(days=20)).isoformat(), amount=round(basis*.2, 2)))
        x, _ = feature_row(s, payments)
        probability = sigmoid(-1.2 + .95*x[3] + 1.5*x[5] - .60*(x[1]-5.5) + .3*bank)
        ratio = max(.03, min(.95, (.23+.22*bank+.07*x[3]-.04*(x[1]-5.5))*rng.lognormvariate(0, .25)))
        if rng.random() < probability:
            cents = round(basis*ratio*100)
            n = rng.randint(1, 5)
            cuts = sorted(rng.sample(range(1, cents), n-1)) if n > 1 else []
            for part in [b-a for a, b in zip([0, *cuts], [*cuts, cents])]:
                when = cutoff + timedelta(days=rng.randint(1, 360))
                payments.append(dict(loan_id=s['loan_id'], payment_date=when.isoformat(),
                                     available_at=(when+timedelta(days=rng.randint(0, 3))).isoformat(), amount=part/100))
        end = horizon_end(cutoff)
        package['snapshots'].append(s)
        package['payments'].extend(payments)
        package['observations'].append(dict(loan_id=s['loan_id'], complete=True,
            observed_until=end.isoformat(), available_at=(end+timedelta(days=7)).isoformat()))
    return package


if __name__ == '__main__':
    data = generate(json.loads((ROOT/'dist/prepurchase-history.json').read_text()))
    (ROOT/'dist/benchmark-history.json').write_text(json.dumps(data, ensure_ascii=False))
    print(f"Synthetic benchmark: {len(data['snapshots'])} snapshots")
