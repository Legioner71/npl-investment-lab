"""Point-in-time, 12-calendar-month pre-purchase scoring pipeline.

Fit: logistic regression + separate sigmoid calibration + Ridge conditional fraction.
Prediction is a probability, not a determination that someone will/will not pay.
Demo models trained on synthetic data must not be used for live investment decisions.
"""
import argparse
import hashlib
import json
import math
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

SEGMENTS = ("bank_early", "bank_late", "mfo_early", "mfo_late")
FEATURES = ["log_basis", "log_dpd", "log_count_30", "log_count_90", "log_count_180",
            "paid_fraction_90", "paid_fraction_previous90", "days_since_payment_180",
            "no_payment_180", *["segment_" + s for s in SEGMENTS]]

def day(value):
    if not isinstance(value, str) or len(value) != 10:
        raise ValueError("Dates must be YYYY-MM-DD")
    return date.fromisoformat(value)

def horizon_end(as_of):
    try: return as_of.replace(year=as_of.year + 1)
    except ValueError: return as_of.replace(year=as_of.year + 1, day=28)

def sigmoid(x):
    return 1 / (1 + math.exp(-max(-40., min(40., x))))

def validate_package(package):
    snapshots = package.get("snapshots")
    payments = package.get("payments")
    if not isinstance(snapshots, list) or not 1 <= len(snapshots) <= 50000:
        raise ValueError("Expected 1–50000 snapshots")
    if not isinstance(payments, list) or len(payments) > 500000:
        raise ValueError("Expected at most 500000 payment records")
    ids, portfolios = set(), {}
    for s in snapshots:
        for key in ("loan_id", "borrower_id", "portfolio_id", "seller_id"):
            if not isinstance(s.get(key), str) or not s[key].strip(): raise ValueError("Missing " + key)
        if s["loan_id"] in ids: raise ValueError("Duplicate loan snapshot")
        ids.add(s["loan_id"])
        cutoff, issued = day(s["as_of_date"]), day(s["issued_at"])
        if issued > cutoff: raise ValueError("Loan issued after cut-off")
        if s["segment"] not in SEGMENTS or s["quality"] not in ("ready", "review"):
            raise ValueError("Unknown segment or quality")
        for key in ("principal", "interest", "penalty", "excluded_amount", "dpd"):
            if type(s.get(key)) not in (int, float) or not math.isfinite(s[key]) or s[key] < 0:
                raise ValueError("Invalid " + key)
        if s["excluded_amount"] > s["principal"] + s["interest"] + s["penalty"]:
            raise ValueError("Exclusions exceed balance")
        if s["portfolio_id"] in portfolios and portfolios[s["portfolio_id"]] != cutoff:
            raise ValueError("One portfolio must have one cut-off date")
        portfolios[s["portfolio_id"]] = cutoff
    for p in payments:
        if p.get("loan_id") not in ids: raise ValueError("Payment refers to unknown loan")
        if day(p["available_at"]) < day(p["payment_date"]): raise ValueError("Payment available before event")
        if type(p.get("amount")) not in (int, float) or not math.isfinite(p["amount"]) or p["amount"] < 0:
            raise ValueError("Payment amounts must be finite and nonnegative; reconcile reversals first")
    return snapshots, payments

def payment_index(payments):
    out = defaultdict(list)
    for p in payments: out[p["loan_id"]].append(p)
    return out

def feature_row(snapshot, payments):
    cutoff = day(snapshot["as_of_date"])
    basis = snapshot["principal"] + snapshot["interest"] + snapshot["penalty"] - snapshot["excluded_amount"]
    if snapshot["quality"] != "ready": return None, "legal_review"
    if basis <= 0: return None, "zero_basis"
    if snapshot.get("history_complete") is not True: return None, "history_unknown"
    start = max(day(snapshot["issued_at"]), cutoff - timedelta(days=180))
    if not snapshot.get("history_start_date") or day(snapshot["history_start_date"]) > start:
        return None, "history_too_short"
    known = [p for p in payments if start < day(p["payment_date"]) <= cutoff
             and day(p["available_at"]) <= cutoff and p["amount"] > 0]
    def count(n): return sum((cutoff - day(p["payment_date"])).days < n for p in known)
    def paid(low, high):
        return sum(p["amount"] for p in known if low <= (cutoff - day(p["payment_date"])).days < high)
    last = min([(cutoff - day(p["payment_date"])).days for p in known], default=180)
    values = [math.log1p(basis), math.log1p(snapshot["dpd"]), math.log1p(count(30)),
              math.log1p(count(90)), math.log1p(count(180)), paid(0, 90) / basis,
              paid(90, 180) / basis, last / 180, float(not known),
              *[float(snapshot["segment"] == s) for s in SEGMENTS]]
    return values, None

def build_samples(package):
    snapshots, payments = validate_package(package)
    index = payment_index(payments)
    observations = {}
    snapshot_ids = {s["loan_id"] for s in snapshots}
    for row in package.get("observations", []):
        if row["loan_id"] in observations: raise ValueError("Duplicate observation")
        if row["loan_id"] not in snapshot_ids:
            raise ValueError("Observation refers to unknown loan")
        if day(row["available_at"]) < day(row["observed_until"]):
            raise ValueError("Observation available before its coverage ends")
        observations[row["loan_id"]] = row
    extract = day(package["meta"]["extract_as_of"])
    samples, excluded = [], defaultdict(int)
    for s in snapshots:
        x, reason = feature_row(s, index[s["loan_id"]])
        if reason: excluded[reason] += 1; continue
        obs = observations.get(s["loan_id"])
        end = horizon_end(day(s["as_of_date"]))
        if not obs or obs.get("complete") is not True or day(obs["observed_until"]) < end or day(obs["available_at"]) > extract:
            excluded["incomplete_outcome"] += 1; continue
        # Only label events available in the complete observation; never use outcomes as features.
        future = [p for p in index[s["loan_id"]] if day(s["as_of_date"]) < day(p["payment_date"]) <= end
                  and day(p["available_at"]) <= day(obs["available_at"])]
        gross = sum(p["amount"] for p in future)
        basis = s["principal"] + s["interest"] + s["penalty"] - s["excluded_amount"]
        if gross > basis + .02:
            excluded["outcome_exceeds_basis"] += 1; continue
        available = max([day(obs["available_at"]), *[day(p["available_at"]) for p in future]])
        samples.append({"snapshot": s, "x": x, "y": int(gross > 0), "gross": gross,
                        "fraction": gross / basis, "basis": basis, "label_available_at": available})
    return samples, dict(excluded)

def temporal_split(samples, config):
    train_end, cal_start, cal_end, test_start, test_end = [day(config[k]) for k in
        ("train_end", "calibration_start", "calibration_end", "test_start", "test_end")]
    if not train_end < cal_start <= cal_end < test_start <= test_end: raise ValueError("Invalid chronological split")
    train = [s for s in samples if day(s["snapshot"]["as_of_date"]) <= train_end and s["label_available_at"] < cal_start]
    seen = {s["snapshot"]["borrower_id"] for s in train}
    cal_candidates = [s for s in samples if cal_start <= day(s["snapshot"]["as_of_date"]) <= cal_end
                      and s["label_available_at"] < test_start]
    calibration = [s for s in cal_candidates if s["snapshot"]["borrower_id"] not in seen]
    seen |= {s["snapshot"]["borrower_id"] for s in calibration}
    test_candidates = [s for s in samples if test_start <= day(s["snapshot"]["as_of_date"]) <= test_end]
    test = [s for s in test_candidates if s["snapshot"]["borrower_id"] not in seen]
    counts = {"train": len(train), "calibration": len(calibration), "test": len(test),
              "purged_borrowers": len(cal_candidates) - len(calibration) + len(test_candidates) - len(test)}
    for name, group in (("train", train), ("calibration", calibration), ("test", test)):
        if len(group) < 40 or len({s["y"] for s in group}) != 2: raise ValueError("Need two outcome classes and at least 40 rows in " + name)
    return train, calibration, test, counts

def raw_prediction(model, x):
    z = [(v - mu) / scale for v, mu, scale in zip(x, model["mean"], model["scale"])]
    logit = model["classifier"]["intercept"] + sum(a * b for a, b in zip(z, model["classifier"]["coefficients"]))
    p = sigmoid(model["calibration"]["intercept"] + model["calibration"]["coefficient"] * logit)
    ratio = max(0., min(1., model["amount"]["intercept"] + sum(a * b for a, b in zip(z, model["amount"]["coefficients"]))))
    return p, ratio, z

def validate_model(model):
    if model.get("features") != FEATURES or model.get("horizon_months") != 12 or model.get("schema_version") != 1:
        raise ValueError("Incompatible model schema")
    for vector in (model["mean"], model["scale"], model["classifier"]["coefficients"], model["amount"]["coefficients"]):
        if len(vector) != len(FEATURES) or any(type(v) not in (int, float) or not math.isfinite(v) for v in vector):
            raise ValueError("Invalid model vector")
    if any(v <= 0 for v in model["scale"]): raise ValueError("Invalid feature scale")
    for v in (model["classifier"]["intercept"], model["calibration"]["coefficient"], model["calibration"]["intercept"], model["amount"]["intercept"]):
        if type(v) not in (int, float) or not math.isfinite(v): raise ValueError("Invalid model coefficient")

def score_package(model, package):
    validate_model(model)
    snapshots, payments = validate_package(package)
    index = payment_index(payments)
    scores = []
    for s in snapshots:
        x, reason = feature_row(s, index[s["loan_id"]])
        out = {"loan_id": s["loan_id"], "borrower_id": s["borrower_id"], "segment": s["segment"],
               "as_of_date": s["as_of_date"], "horizon_end": horizon_end(day(s["as_of_date"])).isoformat(),
               "status": reason or "scored", "probability": None, "conditional": None, "expected": None,
               "unseen_seller": s["seller_id"] not in model["training_sellers"]}
        if x is not None:
            p, ratio, z = raw_prediction(model, x)
            basis = s["principal"] + s["interest"] + s["penalty"] - s["excluded_amount"]
            effects = [model["calibration"]["coefficient"] * a * b for a, b in zip(z, model["classifier"]["coefficients"])]
            out.update(probability=p, conditional=basis * ratio, expected=p * basis * ratio,
                       features=x, effects=effects)
        scores.append(out)
    known = [r for r in scores if r["status"] == "scored"]
    return {"model_id": model["model_id"], "synthetic_training": model["synthetic_training"],
            "horizon_months": 12, "scores": scores, "scored": len(known), "total": len(scores),
            "expected_payers": sum(r["probability"] for r in known),
            "expected_gross": sum(r["expected"] for r in known)}

def train_package(package):
    import numpy as np
    import sklearn
    from sklearn.linear_model import LogisticRegression, Ridge
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import roc_auc_score, brier_score_loss, mean_absolute_error
    samples, excluded = build_samples(package)
    train, calibration, test, counts = temporal_split(samples, package["meta"]["split"])
    scaler = StandardScaler().fit([s["x"] for s in train])
    X = scaler.transform([s["x"] for s in train]); y = np.array([s["y"] for s in train])
    classifier = LogisticRegression(C=1., max_iter=2000, random_state=20261028).fit(X, y)
    cal_logits = classifier.decision_function(scaler.transform([s["x"] for s in calibration]))
    calibrator = LogisticRegression(C=1000., max_iter=2000).fit(cal_logits.reshape(-1, 1), [s["y"] for s in calibration])
    positive = y == 1
    amount = Ridge(alpha=10.).fit(X[positive], np.array([s["fraction"] for s in train])[positive])
    model = {"schema_version": 1, "horizon_months": 12, "features": FEATURES,
             "synthetic_training": package["meta"].get("synthetic") is True,
             "trained_at": package["meta"]["extract_as_of"], "sklearn_version": sklearn.__version__,
             "training_sellers": sorted({s["snapshot"]["seller_id"] for s in train}),
             "mean": scaler.mean_.tolist(), "scale": scaler.scale_.tolist(),
             "classifier": {"intercept": float(classifier.intercept_[0]), "coefficients": classifier.coef_[0].tolist()},
             "calibration": {"intercept": float(calibrator.intercept_[0]), "coefficient": float(calibrator.coef_[0, 0])},
             "amount": {"intercept": float(amount.intercept_), "coefficients": amount.coef_.tolist()}}
    model["model_id"] = ("synthetic-" if model["synthetic_training"] else "external-") + hashlib.sha256(json.dumps(model, sort_keys=True).encode()).hexdigest()[:12]
    predicted = [raw_prediction(model, s["x"]) for s in test]
    p = np.array([r[0] for r in predicted]); actual = np.array([s["y"] for s in test])
    expected = np.array([r[0] * r[1] * s["basis"] for r, s in zip(predicted, test)])
    gross = np.array([s["gross"] for s in test])
    baseline = {}
    for segment in SEGMENTS:
        a = [s for s in train if s["snapshot"]["segment"] == segment]
        pos = [s["fraction"] for s in a if s["y"]]
        baseline[segment] = {"probability": (sum(s["y"] for s in a) + 1) / (len(a) + 2),
                             "conditional_fraction": sum(pos) / len(pos) if pos else 0}
    baseline_p = np.array([baseline[s["snapshot"]["segment"]]["probability"] for s in test])
    baseline_money = np.array([b * baseline[s["snapshot"]["segment"]]["conditional_fraction"] * s["basis"] for b, s in zip(baseline_p, test)])
    bins = []
    for ix in np.array_split(np.argsort(p), 10):
        bins.append({"count": len(ix), "predicted": float(p[ix].mean()), "observed": float(actual[ix].mean())})
    top = np.argsort(-p)[:max(1, math.ceil(len(test) * .2))]
    metrics = {"auc": float(roc_auc_score(actual, p)), "brier": float(brier_score_loss(actual, p)),
               "baseline_brier": float(brier_score_loss(actual, baseline_p)),
               "mae_money": float(mean_absolute_error(gross, expected)),
               "baseline_mae_money": float(mean_absolute_error(gross, baseline_money)),
               "expected_payers": float(p.sum()), "actual_payers": int(actual.sum()),
               "predicted_gross": float(expected.sum()), "actual_gross": float(gross.sum()),
               "gross_error_fraction": float((expected.sum() - gross.sum()) / gross.sum()),
               "top20_payer_share": float(actual[top].mean()), "overall_payer_share": float(actual.mean()),
               "top20_cash_capture": float(gross[top].sum() / gross.sum())}
    report = {"model_id": model["model_id"], "synthetic": model["synthetic_training"], "counts": counts,
              "excluded": excluded, "split": package["meta"]["split"], "metrics": metrics, "calibration_bins": bins,
              "cutoffs": {"train_labels_known_before": min(s["snapshot"]["as_of_date"] for s in calibration),
                          "calibration_labels_known_before": min(s["snapshot"]["as_of_date"] for s in test)},
              "training_baseline": baseline}
    return model, report

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    t = sub.add_parser("train"); t.add_argument("history"); t.add_argument("--model", required=True); t.add_argument("--report", required=True)
    s = sub.add_parser("score"); s.add_argument("model"); s.add_argument("case"); s.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "train":
        model, report = train_package(json.loads(Path(args.history).read_text()))
        Path(args.model).write_text(json.dumps(model, ensure_ascii=False, indent=2))
        Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2))
        print(json.dumps(report["metrics"], ensure_ascii=False))
    else:
        scored = score_package(json.loads(Path(args.model).read_text()), json.loads(Path(args.case).read_text()))
        Path(args.output).write_text(json.dumps(scored, ensure_ascii=False, indent=2))
        print(json.dumps({k:v for k,v in scored.items() if k != "scores"}, ensure_ascii=False))
