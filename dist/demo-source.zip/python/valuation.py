"""Transparent, unlevered, pre-tax NPL scenario valuation. Standard library only.

This demonstration does not train a predictive model or determine legal validity.
Amounts excluded and review flags are inputs, not legal conclusions.
"""
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

SEGMENTS = {
    "bank_early": {"label": "Банк · 90–360 днів", "recovery": .32, "payer": .50, "scale": 5},
    "bank_late": {"label": "Банк · понад 360 днів", "recovery": .18, "payer": .30, "scale": 8},
    "mfo_early": {"label": "МФО · 90–360 днів", "recovery": .21, "payer": .40, "scale": 4},
    "mfo_late": {"label": "МФО · понад 360 днів", "recovery": .10, "payer": .25, "scale": 6},
}
DEFAULTS = {"price": 3190000, "annual_return": .60, "cost_rate": .08,
            "startup": 100000, "multiplier": 1., "payer_multiplier": 1., "delay": 0,
            "cost_mode": "detailed", "monthly_fixed": 12000, "monthly_it": 2500,
            "monthly_overhead": 2500, "fixed_months": 18, "account_monthly": 7,
            "work_months": 12, "action_unit_cost": 18, "actions_per_account": 4,
            "action_month": 1, "legal_share": .10, "legal_unit_cost": 1600,
            "legal_month": 4, "review_unit_cost": 25, "expense_multiplier": 1.,
            "extra_costs": []}

def validate_rows(rows):
    if not rows or len(rows) > 50000:
        raise ValueError("Expected 1–50000 loans")
    seen = set()
    for r in rows:
        if not str(r.get("loan_id", "")).strip() or not str(r.get("borrower_id", "")).strip():
            raise ValueError("Loan and borrower IDs are required")
        if r["loan_id"] in seen:
            raise ValueError("Duplicate loan ID")
        seen.add(r["loan_id"])
        if r.get("segment") not in SEGMENTS or r.get("quality") not in ("ready", "review"):
            raise ValueError("Unknown segment or quality status")
        for key in ("principal", "interest", "penalty", "excluded_amount", "dpd"):
            if not math.isfinite(float(r[key])) or float(r[key]) < 0:
                raise ValueError("Amounts and DPD must be finite and nonnegative")
        if float(r["excluded_amount"]) > sum(float(r[k]) for k in ("principal", "interest", "penalty")) + 1e-8:
            raise ValueError("Excluded amount exceeds face balance")
    if sum(sum(float(r[k]) for k in ("principal", "interest", "penalty")) for r in rows) <= 0:
        raise ValueError("Portfolio face balance must be positive")

def validate_options(o):
    for k in DEFAULTS.keys() - {"cost_mode", "extra_costs"}:
        if not isinstance(o[k], (int, float)) or not math.isfinite(o[k]):
            raise ValueError("Invalid numeric option")
    if o["price"] <= 0 or o["startup"] < 0 or o["annual_return"] < 0 or not 0 <= o["cost_rate"] < 1:
        raise ValueError("Invalid price, expenses, or return")
    if not 0 <= o["multiplier"] <= 3 or not 0 <= o["payer_multiplier"] <= 3 or not 0 <= o["delay"] <= 24 or int(o["delay"]) != o["delay"]:
        raise ValueError("Invalid collection multiplier or delay")
    if o["cost_mode"] not in ("simple", "detailed") or not 0 <= o["legal_share"] <= 1 or o["expense_multiplier"] < 0:
        raise ValueError("Invalid cost assumptions")
    for k in ("monthly_fixed", "monthly_it", "monthly_overhead", "account_monthly", "action_unit_cost",
              "actions_per_account", "legal_unit_cost", "review_unit_cost"):
        if o[k] < 0: raise ValueError("Negative expense")
    for k in ("fixed_months", "work_months"):
        if int(o[k]) != o[k] or not 0 <= o[k] <= 60: raise ValueError("Invalid duration")
    for k in ("action_month", "legal_month"):
        if int(o[k]) != o[k] or not 1 <= o[k] <= 84: raise ValueError("Invalid event month")
    if not isinstance(o["extra_costs"], list) or len(o["extra_costs"]) > 100:
        raise ValueError("Invalid extra costs")
    for item in o["extra_costs"]:
        if not isinstance(item.get("label"), str) or not item["label"].strip() or len(item["label"]) > 120:
            raise ValueError("Extra cost needs a label")
        if not isinstance(item.get("month"), (int, float)) or int(item["month"]) != item["month"] or not 1 <= item["month"] <= 84:
            raise ValueError("Invalid extra cost month")
        if not isinstance(item.get("amount"), (int, float)) or not math.isfinite(item["amount"]) or item["amount"] < 0:
            raise ValueError("Invalid extra cost amount")

def evaluate(rows, options=None):
    validate_rows(rows)
    o = {**DEFAULTS, **(options or {})}
    validate_options(o)
    detailed = o["cost_mode"] == "detailed"
    delay = int(o["delay"])
    fixed_n = int(o["fixed_months"]) + delay if o["fixed_months"] else 0
    work_n = int(o["work_months"]) + delay if o["work_months"] else 0
    horizon = max(36 + delay, *([fixed_n, work_n, int(o["action_month"]), int(o["legal_month"]),
                  *[int(c["month"]) for c in o["extra_costs"]]] if detailed else [0]))
    gross = [0.] * horizon
    by_segment = defaultdict(lambda: {"count": 0, "ready_count": 0, "face": 0., "eligible": 0.,
                                      "gross": 0., "payers": 0., "contribution": 0.})
    face = excluded = review = eligible = 0.
    ready_count = 0
    records = []
    weights = {}
    for key, spec in SEGMENTS.items():
        w = [(t + 1) * math.exp(-t / spec["scale"]) for t in range(36)]
        z = sum(w)
        weights[key] = [v / z for v in w]
    discounts = [(1 + o["annual_return"]) ** (-(t + 1) / 12) for t in range(horizon)]
    def pv(values): return sum(v * d for v, d in zip(values, discounts))
    for r in rows:
        f = sum(float(r[k]) for k in ("principal", "interest", "penalty"))
        e = f - float(r["excluded_amount"])
        face += f
        excluded += float(r["excluded_amount"])
        seg = by_segment[r["segment"]]
        seg["count"] += 1
        seg["face"] += f
        accepted = r["quality"] == "ready"
        spec = SEGMENTS[r["segment"]]
        conditional = e * min(1., spec["recovery"] / spec["payer"] * o["multiplier"])
        probability = min(1., spec["payer"] * o["payer_multiplier"]) if accepted and conditional > 0 else 0.
        expected = probability * conditional
        if not accepted:
            review += e
        else:
            ready_count += 1
            eligible += e
            seg["ready_count"] += 1
            seg["eligible"] += e
            seg["gross"] += expected
            seg["payers"] += probability
        pv_gross = expected * sum(w * discounts[t + delay] for t, w in enumerate(weights[r["segment"]]))
        records.append({"loan_id": r["loan_id"], "segment": r["segment"], "quality": r["quality"],
                        "estimated": accepted, "forecast_status": "scored" if accepted else "legal_review",
                        "weights": weights[r["segment"]],
                        "probability": probability, "conditional": conditional if accepted else 0.,
                        "gross": expected, "pv_gross": pv_gross})
    for key, seg in by_segment.items():
        for t, w in enumerate(weights[key]): gross[t + delay] += seg["gross"] * w
    category_keys = ("commission", "team", "it", "overhead", "accounts", "actions", "legal", "review", "extra")
    categories = {k: [0.] * horizon for k in category_keys}
    factor = o["expense_multiplier"]
    categories["commission"] = [g * o["cost_rate"] * factor for g in gross]
    if detailed:
        for t in range(fixed_n):
            for category, key in (("team", "monthly_fixed"), ("it", "monthly_it"), ("overhead", "monthly_overhead")):
                categories[category][t] = o[key] * factor
        for t in range(work_n): categories["accounts"][t] = len(rows) * o["account_monthly"] * factor
        categories["actions"][int(o["action_month"]) - 1] = len(rows) * o["actions_per_account"] * o["action_unit_cost"] * factor
        categories["legal"][int(o["legal_month"]) - 1] = ready_count * o["legal_share"] * o["legal_unit_cost"] * factor
        categories["review"][0] = len(rows) * o["review_unit_cost"] * factor
        for item in o["extra_costs"]: categories["extra"][int(item["month"]) - 1] += item["amount"] * factor
    costs = [sum(categories[k][t] for k in category_keys) for t in range(horizon)]
    net = [g - c for g, c in zip(gross, costs)]
    initial = o["price"] + o["startup"]
    pv_net = pv(net)
    # Only report IRR for a cash-flow sequence with one sign change. NPV remains valid otherwise.
    cashflow = [-initial, *net]
    signs = [1 if v > 0 else -1 for v in cashflow if abs(v) > 1e-8]
    changes = sum(a != b for a, b in zip(signs, signs[1:]))
    irr = None
    irr_status = "nonconventional" if changes > 1 else "no_positive_cashflow"
    if changes == 1:
        def npv_at(r):
            return sum(v / (1 + r) ** ((t + 1) / 12) for t, v in enumerate(net)) - initial
        lo, hi = -.999999, 1.
        while npv_at(hi) > 0 and hi < 1e6: hi = hi * 2 + 1
        if npv_at(lo) >= 0 and npv_at(hi) <= 0:
            for _ in range(160):
                mid = (lo + hi) / 2
                if npv_at(mid) > 0: lo = mid
                else: hi = mid
            irr = (lo + hi) / 2
            irr_status = "unique"
    operating_cumulative = [0.]
    for v in net: operating_cumulative.append(operating_cumulative[-1] + v)
    suffix_min = operating_cumulative.copy()
    for t in range(horizon - 1, -1, -1): suffix_min[t] = min(suffix_min[t], suffix_min[t + 1])
    payback = None
    for t, value in enumerate(net):
        if value > 0 and operating_cumulative[t] < initial <= operating_cumulative[t + 1] and suffix_min[t + 1] >= initial - 1e-8:
            payback = t + (initial - operating_cumulative[t]) / value
            break
    payers = sum(r["probability"] for r in records)
    allocation = {"payers": 0., "nonpayers": 0., "review": 0., "shared": 0.}
    ordinary = factor * (o["review_unit_cost"] + o["account_monthly"] * work_n + o["actions_per_account"] * o["action_unit_cost"]) if detailed else 0.
    ordinary_pv = factor * (o["review_unit_cost"] * discounts[0] +
                   o["account_monthly"] * sum(discounts[:work_n]) +
                   o["actions_per_account"] * o["action_unit_cost"] * discounts[int(o["action_month"]) - 1]) if detailed else 0.
    legal = factor * o["legal_share"] * o["legal_unit_cost"] if detailed else 0.
    legal_pv = legal * discounts[int(o["legal_month"]) - 1] if detailed else 0.
    for r in records:
        per_account = ordinary + (legal if r["quality"] == "ready" else 0.)
        direct_pv = ordinary_pv + (legal_pv if r["quality"] == "ready" else 0.) + r["pv_gross"] * o["cost_rate"] * factor
        if r["quality"] == "review": allocation["review"] += per_account
        else:
            allocation["payers"] += per_account * r["probability"] + r["gross"] * o["cost_rate"] * factor
            allocation["nonpayers"] += per_account * (1 - r["probability"])
        r["direct_cost"] = per_account + r["gross"] * o["cost_rate"] * factor
        r["contribution"] = r["pv_gross"] - direct_pv
        by_segment[r["segment"]]["contribution"] += r["contribution"]
    allocation["shared"] = sum(sum(categories[k]) for k in ("team", "it", "overhead", "extra")) + o["startup"]
    category_totals = {k: sum(v) for k, v in categories.items()}
    shared_pv = sum(pv(categories[k]) for k in ("team", "it", "overhead", "extra")) + o["startup"]
    cost_total = sum(costs) + o["startup"]
    other = sum(costs) - category_totals["commission"]
    denominator = payers * (1 - o["cost_rate"] * factor)
    break_even_average = (initial + other) / denominator if denominator > 0 else None
    return {"options": o, "count": len(rows), "ready_count": ready_count,
            "collection_months": 36, "unknown_count": len(rows) - ready_count,
            "face": face, "excluded": excluded, "review": review, "eligible": eligible,
            "gross": gross, "costs": costs, "net": net, "categories": categories,
            "category_totals": category_totals, "allocation": allocation, "records": records,
            "gross_total": sum(gross), "cost_total": cost_total,
            "max_price": pv_net - o["startup"], "npv": pv_net - initial,
            "irr": irr, "irr_status": irr_status, "payback": payback, "profit": sum(net) - initial,
            "payers": payers, "nonpayers": ready_count - payers, "shared_pv": shared_pv,
            "funding_peak": initial - min(operating_cumulative),
            "operating_cash_gap": -min(operating_cumulative),
            "cash_balance": [v - initial for v in operating_cumulative],
            "break_even_average": break_even_average,
            "average_payer": sum(gross) / payers if payers > 0 else None,
            "coverage": sum(gross) / (o["price"] + cost_total),
            "segments": dict(by_segment)}

def load_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k in ("principal", "interest", "penalty", "excluded_amount", "dpd"):
            r[k] = float(r[k])
    return rows

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("csv", type=Path)
    p.add_argument("--price", type=float, default=DEFAULTS["price"])
    p.add_argument("--annual-return", type=float, default=DEFAULTS["annual_return"])
    p.add_argument("--cost-rate", type=float, default=DEFAULTS["cost_rate"])
    p.add_argument("--cost-mode", choices=("simple", "detailed"), default="detailed")
    p.add_argument("--payer-multiplier", type=float, default=1.)
    p.add_argument("--delay", type=int, default=0)
    p.add_argument("--multiplier", type=float, default=1.)
    a = p.parse_args()
    print(json.dumps(evaluate(load_csv(a.csv), {"price": a.price, "annual_return": a.annual_return,
          "cost_rate": a.cost_rate, "delay": a.delay, "multiplier": a.multiplier,
          "cost_mode": a.cost_mode, "payer_multiplier": a.payer_multiplier}), ensure_ascii=False, indent=2))
