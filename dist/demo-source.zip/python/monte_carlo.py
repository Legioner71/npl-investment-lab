"""Run the shared Monte Carlo recovery engine locally; Python 3.10+ and Node.js.

Input JSON: {"rows": [registry rows], "options": {valuation assumptions}}.
The bundled dist/demo.json also works. Optional params JSON configures uncertainty.
No second implementation: browser Worker and this CLI use dist/monte-carlo.js.
"""
import argparse
import json
import subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def calculate(input_path, params_path=None):
    command = ['node', str(ROOT / 'dist/monte-carlo.js'), str(Path(input_path).resolve())]
    if params_path:
        command.append(str(Path(params_path).resolve()))
    result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', check=False)
    if result.returncode:
        raise ValueError(result.stderr.strip())
    return json.loads(result.stdout)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input')
    parser.add_argument('--params')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = calculate(args.input, args.params)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, allow_nan=False), encoding='utf-8')
    print(json.dumps({'engine': result['engine'], 'draws': result['params']['draws'],
                      'median_npv': result['metrics']['npv']['p50'],
                      'capital_loss_probability': result['probabilities']['capital_loss']['value']}))
