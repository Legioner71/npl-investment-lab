"""Generate reproducible synthetic data. No real borrowers or empirical calibration."""
import csv
import json
import random
from pathlib import Path
from valuation import DEFAULTS, evaluate

ROOT = Path(__file__).resolve().parents[1]
rng = random.Random(19710421)
rows = []
for i in range(1200):
    segment = ("bank_early", "bank_late", "mfo_early", "mfo_late")[i % 4]
    bank = segment.startswith("bank")
    principal = round(rng.uniform(9000, 58000) if bank else rng.uniform(2500, 15000), 2)
    interest = round(principal * rng.uniform(.08, .35), 2)
    penalty = round(principal * rng.uniform(.02, .18), 2)
    # Explicit synthetic adjustment, not an implementation of Ukrainian legislation.
    excluded = round(penalty + (interest * .25 if i % 11 == 0 else 0), 2)
    rows.append({"loan_id": f"DEMO-{i+1:05d}", "borrower_id": f"B-{(i*7)%1019:05d}",
                 "segment": segment, "principal": principal, "interest": interest,
                 "penalty": penalty, "excluded_amount": excluded,
                 "dpd": rng.randint(90, 360) if segment.endswith("early") else rng.randint(361, 1600),
                 "quality": "review" if i % 17 == 0 else "ready"})
result = evaluate(rows)
defaults = {**DEFAULTS, "price": 3190000}
baseline = evaluate(rows, defaults)
observed = [round(v * f, 2) for v, f in zip(baseline["gross"], (1.08, .96, .91, 1.04, .89, .94))]
data = {"meta": {"name": "UA Consumer / демонстраційний портфель", "cutoff": "2026-10-28",
                 "synthetic": True, "seed": 19710421, "currency": "UAH", "defaults": defaults,
                 "observed_gross": observed}, "loans": rows}
(ROOT / "dist" / "demo.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
with (ROOT / "dist" / "demo-register.csv").open("w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys())
    w.writeheader()
    w.writerows(rows)
print(json.dumps({"loans": len(rows), "face": baseline["face"], "max_price": baseline["max_price"],
                  "price": defaults["price"], "irr": baseline["irr"]}, ensure_ascii=False))
