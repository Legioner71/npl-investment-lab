"""Check the exported package's SHA256 manifest. No third-party dependencies."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    manifest=json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
    failures=[]
    for entry in manifest['files']:
        path=ROOT/entry['path']
        if not path.is_file():failures.append('Missing: '+entry['path']);continue
        if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:failures.append('Changed: '+entry['path'])
    for name in ['dist/index.html','run_local.py','.github/workflows/pages.yml']:
        if not (ROOT/name).is_file():failures.append('Missing: '+name)
    if failures:
        print('\n'.join(failures));return 1
    print('Package verified:',len(manifest['files']),'files match SHA256 manifest')
    print('The nested source ZIP and manifest itself are excluded from recursive hashing.')
    return 0

if __name__=='__main__':raise SystemExit(main())
