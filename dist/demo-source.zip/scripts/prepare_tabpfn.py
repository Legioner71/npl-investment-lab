"""Download/check the exact public TabPFN v2 weights and prepare local context."""
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))

if __name__=='__main__':
    from model_benchmark import load_candidate
    bundle=json.loads((ROOT/'dist/model-bundle.json').read_text(encoding='utf-8'))
    artifact=bundle['models']['tabpfn']
    load_candidate(artifact)
    print('TabPFN v2 is ready. Exact checkpoint checksums matched the bundle.')
    print('Cache:',Path.home()/'.cache/tabpfn')
